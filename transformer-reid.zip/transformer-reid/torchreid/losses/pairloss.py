from __future__ import absolute_import

import torch
from torch import nn
from torch.autograd import Variable
from torchreid.evaluator import accuracy


class PairLoss(nn.Module):
    def __init__(self, sampling_rate=3):
        super(PairLoss, self).__init__()
        self.sampling_rate = sampling_rate
        self.BCE = nn.BCEWithLogitsLoss() #BCELoss()
        self.BCE.size_average = True

    def forward(self, score, tar_probe, tar_gallery):
        cls_Size = score.size()
        N_probe = cls_Size[0]
        N_gallery = cls_Size[1]

        tar_gallery = tar_gallery.unsqueeze(0)
        tar_probe = tar_probe.unsqueeze(1)
        # ele-wise equality
        mask = tar_probe.expand(N_probe, N_gallery).eq(tar_gallery.expand(N_probe, N_gallery))
        mask = mask.view(-1).cpu().numpy().tolist()

        score = score.contiguous()
        samplers = score.view(-1)
        labels = torch.FloatTensor(mask).cuda()  # Variable(torch.Tensor(mask).cuda())

        positivelabel = torch.Tensor(mask)
        negativelabel = 1 - positivelabel
        positiveweightsum = torch.sum(positivelabel)
        negativeweightsum = torch.sum(negativelabel)
        neg_relativeweight = positiveweightsum / negativeweightsum * self.sampling_rate
        weights = (positivelabel + negativelabel * neg_relativeweight)
        weights = weights / torch.sum(weights) / 10
        self.BCE.weight = weights.cuda()
        loss = self.BCE(samplers, labels)

        samplers_data = samplers.data
        samplers_neg = 1 - samplers_data
        samplerdata = torch.cat((samplers_neg.unsqueeze(1), samplers_data.unsqueeze(1)), 1)

        labeldata = torch.LongTensor(mask).cuda()
        prec, = accuracy(samplerdata, labeldata)

        return loss, prec



if __name__ == '__main__':
    p = PairLoss()

    import torch as t

    a = t.rand(16, requires_grad=True).cuda()
    l, p = p(t.rand(16,16,requires_grad=True).cuda(),
          a,
          a)
    # l.backward()
    print(l, p)