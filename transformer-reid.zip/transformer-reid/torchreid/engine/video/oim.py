from __future__ import division, print_function, absolute_import

from torchreid import metrics
from torchreid.losses import CrossEntropyLoss, OIMLoss, PairLoss
import torch
from torchreid.engine.engine import Engine
from torchreid.evaluator import ATTEvaluator
from torch.utils.tensorboard import SummaryWriter
import time
import datetime
from torch.cuda.amp import autocast as autocast
from torch.nn.functional import cosine_similarity

class VideoOIMEngine(Engine):
    r"""Triplet-loss engine for image-reid.

    Args:
        datamanager (DataManager): an instance of ``torchreid.data.ImageDataManager``
            or ``torchreid.data.VideoDataManager``.
        model (nn.Module): model instance.
        optimizer (Optimizer): an Optimizer.
        margin (float, optional): margin for triplet loss. Default is 0.3.
        weight_t (float, optional): weight for triplet loss. Default is 1.
        weight_x (float, optional): weight for softmax loss. Default is 1.
        scheduler (LRScheduler, optional): if None, no learning rate decay will be performed.
        use_gpu (bool, optional): use gpu. Default is True.
        label_smooth (bool, optional): use label smoothing regularizer. Default is True.

    Examples::

        import torchreid
        datamanager = torchreid.data.ImageDataManager(
            root='path/to/reid-data',
            sources='market1501',
            height=256,
            width=128,
            combineall=False,
            batch_size=32,
            num_instances=4,
            train_sampler='RandomIdentitySampler' # this is important
        )
        model = torchreid.models.build_model(
            name='resnet50',
            num_classes=datamanager.num_train_pids,
            loss='triplet'
        )
        model = model.cuda()
        optimizer = torchreid.optim.build_optimizer(
            model, optim='adam', lr=0.0003
        )
        scheduler = torchreid.optim.build_lr_scheduler(
            optimizer,
            lr_scheduler='single_step',
            stepsize=20
        )
        engine = torchreid.engine.ImageTripletEngine(
            datamanager, model, optimizer, margin=0.3,
            weight_t=0.7, weight_x=1, scheduler=scheduler
        )
        engine.run(
            max_epoch=60,
            save_dir='log/resnet50-triplet-market1501',
            print_freq=10
        )
    """

    def __init__(
            self,
            datamanager,
            model,
            optimizer,
            margin=0.3,
            weight_o=1,
            weight_c=1,
            scheduler=None,
            use_gpu=True,
            label_smooth=True,
            pooling_method='avg',
            save_feat = False,
    ):
        super(VideoOIMEngine, self).__init__(datamanager, use_gpu)

        self.model = model
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.register_model('model', model, optimizer, scheduler)
        self.pooling_method = pooling_method
        self.save_feat = save_feat

        assert weight_o >= 0 and weight_c >= 0
        assert weight_o + weight_c > 0
        self.weight_o = weight_o
        self.weight_c = weight_c

        self.criterion_o = OIMLoss(512, 625,
                            scalar=30, momentum=0.5).cuda()
        self.criterion_c = CrossEntropyLoss(
            num_classes=self.datamanager.num_train_pids,
            use_gpu=self.use_gpu,
            label_smooth=label_smooth
        )

    def forward_backward(self, data):

        # (b, s, c, h, w) -> (b*s, c, h, w)
        imgs, pids = self.parse_data_for_train(data)

        if self.use_gpu:
            imgs = imgs.cuda()
            pids = pids.cuda()

        if self.amp:
            with autocast():
                outputs, features = self.model(imgs)

                loss = 0
                loss_summary = {}

                if self.weight_o > 0:
                    loss_o, oim_id = self.criterion_o(features, pids)
                    # if self.epoch >= 2:
                    loss += self.weight_o * loss_o
                    loss_summary['loss_oim'] = self.weight_o * loss_o.item()
                    loss_summary['oim_acc'] = metrics.accuracy(oim_id, pids)[0].item()


                if self.weight_c > 0:
                    loss_c = self.criterion_c(outputs, pids)
                    loss += self.weight_c * loss_c
                    loss_summary['loss_ce'] = self.weight_c * loss_c
                    loss_summary['ce_acc'] = metrics.accuracy(outputs, pids)[0].item()
                    loss_summary['loss_total'] = loss.item()

                assert loss_summary

                self.scaler.scale(loss).backward()
                self.scaler.step(self.optimizer)
                self.scaler.update()

                self.optimizer.zero_grad()
                # loss.backward()
                # self.optimizer.step()
                self.scheduler.step()

        return loss_summary



    def parse_data_for_train(self, data):
        imgs = data['img']
        pids = data['pid']
        # if imgs.dim() == 5:
            # b: batch size
            # s: sqeuence length
            # c: channel depth
            # h: height
            # w: width
            # b, s, c, h, w = imgs.size()
            # imgs = imgs.view(b * s, c, h, w)
            # pids = pids.view(b, 1).expand(b, s)
            # pids = pids.contiguous().view(b * s)
        return imgs, pids

    def extract_features(self, input):
        # b: batch size
        # s: sqeuence length
        # c: channel depth
        # h: height
        # w: width
        # b, s, c, h, w = input.size()
        features = self.model(input)[1]
        return features



class VideoOIMPairLossEngine(Engine):

    def __init__(
            self,
            datamanager,
            model,
            optimizer,
            weight_o=1,
            weight_v=1,
            weight_c=1,
            scheduler=None,
            use_gpu=True,
            label_smooth=True,
    ):
        super(VideoOIMPairLossEngine, self).__init__(datamanager, use_gpu)

        self.model = model
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.register_model('model', model, optimizer, scheduler)

        # assert weight_o >= 0 and weight_v >= 0
        # assert weight_o + weight_v > 0
        self.weight_o = weight_o
        self.weight_v = weight_v
        self.weight_c = weight_c

        self.criterion_o = OIMLoss(model.feat_num2, 625,
                            scalar=30, momentum=0.5).cuda()
        self.criterion_v = PairLoss()
        self.criterion_c = CrossEntropyLoss(
            num_classes=self.datamanager.num_train_pids,
            use_gpu=self.use_gpu,
            label_smooth=label_smooth
        )

    def forward_backward(self, data):

        # Data preprocessing
        # imgs: (b, s, c, h, w) -> (b*s, c, h, w)
        # pids: (b) -> (b*s)
        # targets: (b)
        imgs, pids, targets = self.parse_data_for_train(data)

        sample_num, seq_len = imgs.shape[0], imgs.shape[1]
        targets = targets.data
        ver_targets = targets.view(int(sample_num / 2), -1)
        tar_probe = ver_targets[:, 0]
        tar_gallery = ver_targets[:, 1]

        if self.use_gpu:
            imgs = imgs.cuda()
            pids = pids.cuda()
            targets = targets.cuda()

        # Forward
        # feat: (bs*s, 128) 用作oim loss计算
        # encode_scores: (bs/2, bs/2) 用作pair loss计算
        if self.amp:
            with autocast():
                sa_clsout, encodemat, sa_out, clf_out = self.model(imgs)

                ## expand the target label ID loss
                loss = 0
                loss_summary = {}
                # oim loss：输入特征和类别
                if self.weight_o > 0:
                    loss_o, oim_id = self.criterion_o(sa_out, targets) #feat2.view(sample_num * seq_len, -1), pids
                    # if self.epoch >= 2:
                    loss += self.weight_o * loss_o
                    loss_summary['loss_oim'] = self.weight_o * loss_o.item()
                    loss_summary['oim_acc'] = metrics.accuracy(oim_id, targets)[0].item()

                if self.weight_v > 0:
                    loss_v, prec_v = self.criterion_v(encodemat, tar_probe, tar_gallery)
                    loss += self.weight_v * loss_v
                    loss_summary['loss_ver'] = self.weight_v * loss_v.item()
                    loss_summary['ver_acc'] = prec_v.item()

                if self.weight_c > 0:
                    # loss_c0 = self.criterion_c(clf_out, pids)
                    # loss += self.weight_c * loss_c0
                    # loss_summary['loss_ce0'] = self.weight_c * loss_c0
                    # loss_summary['ce0_acc'] = metrics.accuracy(clf_out, pids)[0].item()

                    loss_c_sa = self.criterion_c(sa_clsout, targets)
                    loss += self.weight_c * loss_c_sa
                    loss_summary['loss_ce_sa_out'] = self.weight_c * loss_c_sa
                    loss_summary['ce_sa_out_acc'] = metrics.accuracy(sa_clsout, targets)[0].item()

                    loss_summary['loss_total'] = loss.item()
                    loss_summary['token0&1 cosine similarity'] = cosine_similarity( (self.model.backbone.cls_token + self.model.backbone.pos_embed[:,0:1]), self.model.backbone.cls_token2, dim=2).item()

                # loss.backward()
                # self.optimizer.step()
                # if self.epoch >= 2:

                self.scaler.scale(loss).backward()
                self.scaler.step(self.optimizer)
                self.scheduler.step()
                self.scaler.update()

                self.optimizer.zero_grad()

                del loss_o, loss_v, loss

        else:
            sa_clsout, encodemat, sa_out, clf_out = self.model(imgs)

            ## expand the target label ID loss
            loss = 0
            loss_summary = {}
            # oim loss：输入特征和类别
            if self.weight_o > 0:
                loss_o, oim_id = self.criterion_o(sa_out, targets)  # feat2.view(sample_num * seq_len, -1), pids
                # if self.epoch >= 2:
                loss += self.weight_o * loss_o
                loss_summary['loss_oim'] = self.weight_o * loss_o.item()
                loss_summary['oim_acc'] = metrics.accuracy(oim_id, targets)[0].item()

            if self.weight_v > 0:
                loss_v, prec_v = self.criterion_v(encodemat, tar_probe, tar_gallery)
                loss += self.weight_v * loss_v
                loss_summary['loss_ver'] = self.weight_v * loss_v.item()
                loss_summary['ver_acc'] = prec_v.item()

            if self.weight_c > 0:
                # loss_c0 = self.criterion_c(clf_out, pids)
                # loss += self.weight_c * loss_c0
                # loss_summary['loss_ce0'] = self.weight_c * loss_c0
                # loss_summary['ce0_acc'] = metrics.accuracy(clf_out, pids)[0].item()

                loss_c_sa = self.criterion_c(sa_clsout, targets)
                loss += self.weight_c * loss_c_sa
                loss_summary['loss_ce_sa_out'] = self.weight_c * loss_c_sa
                loss_summary['ce_sa_out_acc'] = metrics.accuracy(sa_clsout, targets)[0].item()

                loss_summary['loss_total'] = loss.item()
                loss_summary['token0&1 cosine similarity'] = cosine_similarity(
                    (self.model.backbone.cls_token + self.model.backbone.pos_embed[:, 0:1]),
                    self.model.backbone.cls_token2, dim=2).item()

            loss.backward()
            self.optimizer.step()
            self.scheduler.step()
            self.optimizer.zero_grad()


        return loss_summary



    def parse_data_for_train(self, data):
        imgs = data['img']
        pids = data['pid']
        targets = pids
        if imgs.dim() == 5:
            # b: batch size
            # s: sqeuence length
            # c: channel depth
            # h: height
            # w: width
            b, s, c, h, w = imgs.size()
            # imgs = imgs.view(b * s, c, h, w)
            pids = pids.view(b, 1).expand(b, s)
            pids = pids.contiguous().view(b * s)
        return imgs, pids, targets

    def extract_features(self, input):
        features, _ = self.model(input)
        features = features.view(b, s, -1)
        if self.pooling_method == 'avg':
            features = torch.mean(features, 1)
        else:
            features = torch.max(features, 1)[0]
        return features

    @torch.no_grad()
    def _evaluate(
            self,
            dataset_name='',
            query_loader=None,
            gallery_loader=None,
            dist_metric='euclidean',
            normalize_feature=False,
            visrank=False,
            visrank_topk=10,
            save_dir='',
            use_metric_cuhk03=False,
            ranks=[1, 5, 10, 20],
            rerank=False
    ):
        self.set_model_mode('eval')
        evaluator = ATTEvaluator(self.model, self.criterion_v)
        mAP, top1, top5, top10, top20 = evaluator.evaluate(query_loader, gallery_loader)
        # mAP, top1, top5, top10, top20 = evaluator.evaluate_full_seq(query_loader, gallery_loader)
        return mAP, top1, top5





