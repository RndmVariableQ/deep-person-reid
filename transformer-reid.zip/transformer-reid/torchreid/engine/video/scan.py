from __future__ import division, print_function, absolute_import

from torchreid import metrics
from torchreid.losses import CrossEntropyLoss, OIMLoss, PairLoss
import torch
from torchreid.engine.engine import Engine
from torchreid.evaluator import ATTEvaluator
from torch.utils.tensorboard import SummaryWriter
import time
import datetime
from torch.cuda.amp import autocast as autocast


class VideoSCANEngine(Engine):

    def __init__(
            self,
            datamanager,
            model,
            optimizer,
            weight_o=1,
            weight_v=1,
            weight_c=1,
            scheduler=None,
            use_gpu=True,
            label_smooth=True,
            pooling_method='avg'
    ):
        super(VideoSCANEngine, self).__init__(datamanager, use_gpu)

        self.model = model
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.register_model('model', model, optimizer, scheduler)
        self.pooling_method = pooling_method

        # assert weight_o >= 0 and weight_v >= 0
        # assert weight_o + weight_v > 0
        self.weight_o = weight_o
        self.weight_v = weight_v
        self.weight_c = weight_c

        self.criterion_o = OIMLoss(model.feat_num, 625,
                            scalar=30, momentum=0.5).cuda()
        self.criterion_v = PairLoss()
        self.criterion_c = CrossEntropyLoss(
            num_classes=self.datamanager.num_train_pids,
            use_gpu=self.use_gpu,
            label_smooth=label_smooth
        )

    def forward_backward(self, data):

        # Data preprocessing
        # imgs: (b, s, c, h, w) -> (b*s, c, h, w)
        # pids: (b) -> (b*s)
        # targets: (b)
        imgs, pids, targets = self.parse_data_for_train(data)
        if self.use_gpu:
            imgs = imgs.cuda()
            pids = pids.cuda()
            # targets = targets.cuda()

        sample_num, seq_len = imgs.shape[0], imgs.shape[1]
        targets = targets.data
        targets = targets.view(int(sample_num / 2), -1)
        tar_probe = targets[:, 0]
        tar_gallery = targets[:, 1]

        # Forward
        # feat: (bs*s, 128) 用作oim loss计算
        # encode_scores: (bs/2, bs/2) 用作pair loss计算
        if self.amp:
            with autocast():
                feat, clf_out, encodemat = self.model(imgs)

                ## expand the target label ID loss
                loss = 0
                loss_summary = {}
                # oim loss：输入特征和类别
                if self.weight_o > 0:
                    loss_o, oim_id = self.criterion_o(feat.view(sample_num*seq_len, -1), pids)
                    # if self.epoch >= 2:
                    loss += self.weight_o * loss_o
                    loss_summary['loss_oim'] = self.weight_o * loss_o.item()
                    loss_summary['oim_acc'] = metrics.accuracy(oim_id, pids)[0].item()

                if self.weight_v > 0:
                    loss_v, prec_v = self.criterion_v(encodemat, tar_probe, tar_gallery)
                    loss += self.weight_v * loss_v
                    loss_summary['loss_ver'] = self.weight_v * loss_v.item()
                    loss_summary['ver_acc'] = prec_v.item()

                if self.weight_c > 0:
                    loss_c = self.criterion_c(clf_out, pids)
                    loss += self.weight_c * loss_c
                    loss_summary['loss_ce'] = self.weight_c * loss_c
                    loss_summary['ce_acc'] = metrics.accuracy(clf_out, pids)[0].item()
                    loss_summary['loss_total'] = loss.item()

                # loss.backward()
                # self.optimizer.step()
                # if self.epoch >= 2:

                self.scaler.scale(loss).backward()
                self.scaler.step(self.optimizer)
                self.scaler.update()

                self.scheduler.step()
                self.optimizer.zero_grad()


        else:
            feat, clf_out, encodemat = self.model(imgs)

            ## expand the target label ID loss
            loss = 0
            loss_summary = {}
            # oim loss：输入特征和类别
            if self.weight_o > 0:
                loss_o, oim_id = self.criterion_o(feat.view(sample_num * seq_len, -1), pids)
                # if self.epoch >= 2:
                loss += self.weight_o * loss_o
                loss_summary['loss_oim'] = self.weight_o * loss_o.item()
                loss_summary['oim_acc'] = metrics.accuracy(oim_id, pids)[0].item()

            if self.weight_v > 0:
                loss_v, prec_v = self.criterion_v(encodemat, tar_probe, tar_gallery)
                loss += self.weight_v * loss_v
                loss_summary['loss_ver'] = self.weight_v * loss_v.item()
                loss_summary['ver_acc'] = prec_v.item()

            if self.weight_c > 0:
                loss_c = self.criterion_c(clf_out, pids)
                loss += self.weight_c * loss_c
                loss_summary['loss_ce'] = self.weight_c * loss_c
                loss_summary['ce_acc'] = metrics.accuracy(clf_out, pids)[0].item()
                loss_summary['loss_total'] = loss.item()

            loss.backward()
            self.optimizer.step()
            self.scheduler.step()
            self.optimizer.zero_grad()

        return loss_summary



    def parse_data_for_train(self, data):
        imgs = data['img']
        pids = data['pid']
        targets = pids
        if imgs.dim() == 5:
            # b: batch size
            # s: sqeuence length
            # c: channel depth
            # h: height
            # w: width
            b, s, c, h, w = imgs.size()
            # imgs = imgs.view(b * s, c, h, w)
            pids = pids.view(b, 1).expand(b, s)
            pids = pids.contiguous().view(b * s)
        return imgs, pids, targets

    def extract_features(self, input):
        features, _ = self.model(input)
        features = features.view(b, s, -1)
        if self.pooling_method == 'avg':
            features = torch.mean(features, 1)
        else:
            features = torch.max(features, 1)[0]
        return features

    @torch.no_grad()
    def _evaluate(
            self,
            dataset_name='',
            query_loader=None,
            gallery_loader=None,
            dist_metric='euclidean',
            normalize_feature=False,
            visrank=False,
            visrank_topk=10,
            save_dir='',
            use_metric_cuhk03=False,
            ranks=[1, 5, 10, 20],
            rerank=False
    ):
        self.set_model_mode('eval')
        evaluator = ATTEvaluator(self.model, self.criterion_v)
        mAP, top1, top5, top10, top20 = evaluator.evaluate(query_loader, gallery_loader)
        return mAP, top1, top5