from __future__ import absolute_import
import torch
import torch.nn.init as init
import numpy as np
from torch import nn
from torch.nn import functional as F
import torch.nn.init as init
from torchreid.models.transformer import *
import torchreid
from timm.models.vision_transformer import VisionTransformer, Block
import torch
import torch.nn as nn
from functools import partial

from timm.data import IMAGENET_DEFAULT_MEAN, IMAGENET_DEFAULT_STD
from timm.models.helpers import load_pretrained
from timm.models.layers import DropPath, to_2tuple, trunc_normal_


class Verifier(nn.Module):
    def __init__(self, feat_num, class_num, drop=0):
        super(Verifier, self).__init__()
        self.feat_num = feat_num
        self.class_num = class_num
        self.drop = drop

        # BN layer
        self.classifierBN = nn.BatchNorm1d(self.feat_num)
        # feat classifeir
        self.classifierlinear = nn.Linear(self.feat_num, self.class_num)
        # dropout_layer
        self.drop = drop
        if self.drop > 0:
            self.droplayer = nn.Dropout(drop)

        init.constant_(self.classifierBN.weight, 1)
        init.constant_(self.classifierBN.bias, 0)

        init.normal_(self.classifierlinear.weight, std=0.001)
        init.constant_(self.classifierlinear.bias, 0)

    def forward(self, probe, gallery2, probe2, gallery):
        S_gallery2 = gallery2.size()
        N_probe = S_gallery2[0]
        N_gallery = S_gallery2[1]
        feat_num = S_gallery2[2]

        # 全部广播成N,N,d
        probe = probe.expand(N_probe, N_gallery, feat_num)
        gallery = gallery.expand(N_probe, N_gallery, feat_num)


        slice0 = 64
        if N_probe < slice0:
            diff1, diff2 = probe - gallery, probe2 - gallery2
            diff = diff1 * diff2
            pg_size = diff.size()
            p_size, g_size = pg_size[0], pg_size[1]
            diff = diff.view(p_size * g_size, -1)
            diff = diff.contiguous()
            diff = self.classifierBN(diff)
            if self.drop > 0:
                diff = self.droplayer(diff)
            cls_encode = self.classifierlinear(diff)
            cls_encode = cls_encode.view(p_size, g_size, -1)

        else:
            iter_time_0 = int(np.floor(N_probe / slice0))
            for i in range(0, iter_time_0):
                before_index_0 = i * slice0
                after_index_0 = (i + 1) * slice0

                probe_tmp = probe[before_index_0:after_index_0, :, :]
                gallery_tmp = gallery[before_index_0:after_index_0, :, :]

                probe2_tmp = probe2[before_index_0:after_index_0, :, :]
                gallery2_tmp = gallery2[before_index_0:after_index_0, :, :]

                diff1_tmp, diff2_tmp = probe_tmp - gallery_tmp, probe2_tmp - gallery2_tmp
                # diff1_tmp = diff1[before_index_0:after_index_0, :, :]
                # diff2_tmp = diff2[before_index_0:after_index_0, :, :]
                diff_tmp = diff1_tmp * diff2_tmp

                pg_size = diff_tmp.size()
                p_size, g_size = pg_size[0], pg_size[1]
                diff_tmp = diff_tmp.view(p_size * g_size, -1)
                diff_tmp = diff_tmp.contiguous()
                diff_tmp = self.classifierBN(diff_tmp)

                if self.drop > 0:
                    diff_tmp = self.droplayer(diff_tmp)
                cls_encode_tmp = self.classifierlinear(diff_tmp)
                cls_encode_tmp = cls_encode_tmp.view(p_size, g_size, -1)
                if i == 0:
                    cls_encode = cls_encode_tmp
                else:
                    cls_encode = torch.cat((cls_encode, cls_encode_tmp), 0)
            before_index_0 = iter_time_0 * slice0
            after_index_0 = N_probe
            if after_index_0 > before_index_0:
                probe_tmp = probe[before_index_0:after_index_0, :, :]
                gallery_tmp = gallery[before_index_0:after_index_0, :, :]
                probe2_tmp = probe2[before_index_0:after_index_0, :, :]
                gallery2_tmp = gallery2[before_index_0:after_index_0, :, :]
                diff1_tmp, diff2_tmp = probe_tmp - gallery_tmp, probe2_tmp - gallery2_tmp
                # diff1_tmp = diff1[before_index_0:after_index_0, :, :]
                # diff2_tmp = diff2[before_index_0:after_index_0, :, :]
                diff_tmp = diff1_tmp * diff2_tmp
                pg_size = diff_tmp.size()
                p_size, g_size = pg_size[0], pg_size[1]
                diff_tmp = diff_tmp.view(p_size * g_size, -1)
                diff_tmp = diff_tmp.contiguous()
                diff_tmp = self.classifierBN(diff_tmp)
                if self.drop > 0:
                    diff_tmp = self.droplayer(diff_tmp)
                cls_encode_tmp = self.classifierlinear(diff_tmp)
                cls_encode_tmp = cls_encode_tmp.view(p_size, g_size, -1)
                cls_encode = torch.cat((cls_encode, cls_encode_tmp), 0)

        return cls_encode




class Self_attn_module(nn.Module):
    """
    gallery_x(B*S*768), pooled_probe(B*768) -> B X B x 128
    i.e. for each seq A's frame-lv feats and a pooled seq B's seq-lv feat, the model outputs a pooled cross-attn feat for seq A
    """
    def __init__(self, input_dim=768, output_dim=128, pos_embed=False, depth=1,
                 num_heads=8, mlp_ratio=4., qkv_bias=False, qk_scale=None, drop_rate=0.1, attn_drop_rate=0.05,
                 drop_path_rate=0.05, norm_layer=nn.LayerNorm, loss=['softmax'], num_classes=650, feat_fc=None, attn=None
                 ):
        super(Self_attn_module, self).__init__()
        self.loss = loss
        self.num_classes = num_classes
        self.input_dim = input_dim
        self.output_dim = output_dim  # num_features for consistency with other models

        # FC
        if feat_fc is None:
            self.feat_fc = nn.Sequential(nn.Linear(self.input_dim, self.output_dim),
                                             nn.BatchNorm1d(self.output_dim))
        else:
            self.feat_fc = feat_fc


        # num_patches = self.patch_embed.num_patches
        # self.seq_token = nn.Parameter(torch.zeros(1, 1, self.output_dim))

        self.pos_embed = pos_embed
        if self.pos_embed:
            self.pos_embed_q = nn.Parameter(torch.zeros(1, 1, self.output_dim))
            self.pos_embed_g = nn.Parameter(torch.zeros(1, 1, self.output_dim))
            trunc_normal_(self.pos_embed_q, std=.02)
            trunc_normal_(self.pos_embed_g, std=.02)
        self.pos_drop = nn.Dropout(p=drop_rate)

        if attn is None:
            dpr = [x.item() for x in torch.linspace(0, drop_path_rate, depth)]  # stochastic depth decay rule dpr越来越高
            self.blocks = nn.ModuleList([
                Block(
                    dim=self.output_dim, num_heads=num_heads, mlp_ratio=mlp_ratio, qkv_bias=qkv_bias, qk_scale=qk_scale,
                    drop=drop_rate, attn_drop=attn_drop_rate, drop_path=dpr[i], norm_layer=norm_layer)
                for i in range(depth)])
        else:
            self.blocks = attn

        self.norm = norm_layer(self.input_dim)


        # Classifier head
        # if 'softmax' in self.loss:
        #     self.head = nn.Linear(self.output_dim, num_classes) if num_classes > 0 else nn.Identity()

        # trunc_normal_(self.seq_token, std=.02)
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)


    def trsfmr_attn(self, x, mode):
        """x: BxSx768"""

        if self.pos_embed and mode == 'q':
            x = x + self.pos_embed_q
        elif self.pos_embed and mode == 'g':
            x = x + self.pos_embed_g
        B = x.shape[0]

        # seq_tokens = self.seq_token.expand(B, -1, -1)  # stole seq_tokens impl from Phil Wang, thanks
        # x = torch.cat((seq_tokens, x), dim=1)

        x = self.pos_drop(x)

        for blk in self.blocks:
            x = blk(x)

        x = self.norm(x)
        return x.mean(dim=1)

    def forward(self, x, mode='q'):
        bs, l = x.shape[0], x.shape[1]
        x = self.trsfmr_attn(x, mode)
        x = self.feat_fc(x) #.view(bs, l, -1)
        # if not self.training and len(self.loss) == 0:
        return x, 0
        # y = self.head(v)
        # return v, y




class Cros_attn_module(nn.Module):
    """
    输入B1xS1x768 B2xS2x768， 输出B1xB2x768 (temporal pooling) 即两两做cross attn
    不加seq_token, attn后取前S1个token维做avg pooling,
    """
    def __init__(self, input_dim=768, output_dim=128, pos_embed=True, depth=1,
                 num_heads=8, mlp_ratio=4., qkv_bias=False, qk_scale=None, drop_rate=0.1, attn_drop_rate=0.05,
                 drop_path_rate=0.05, norm_layer=nn.LayerNorm, feat_fc=None, attn=None
                 ):
        super(Cros_attn_module, self).__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim


        # Positional embedding & cls token
        self.seq_token = nn.Parameter(torch.zeros(1, 1, output_dim))
        self.pos_embed = pos_embed
        if self.pos_embed:
            self.pos_embed_q = nn.Parameter(torch.zeros(1, 1, input_dim)) # the length of input sequence is uncertain
            self.pos_embed_g = nn.Parameter(torch.zeros(1, 1, input_dim))
            trunc_normal_(self.pos_embed_q, std=.02)
            trunc_normal_(self.pos_embed_g, std=.02)

        # FC
        if feat_fc is None:
            self.feat_fc = nn.Sequential(nn.Linear(self.input_dim, self.output_dim),
                                             nn.BatchNorm1d(self.output_dim))
        else:
            self.feat_fc = feat_fc


        # pos dropout
        self.pos_drop = nn.Dropout(p=drop_rate)
        if attn is None:
            dpr = [x.item() for x in torch.linspace(0, drop_path_rate, depth)]  # stochastic depth decay rule dpr越来越高
            self.blocks = nn.ModuleList([
                Block(
                    dim=self.output_dim, num_heads=num_heads, mlp_ratio=mlp_ratio, qkv_bias=qkv_bias, qk_scale=qk_scale,
                    drop=drop_rate, attn_drop=attn_drop_rate, drop_path=dpr[i], norm_layer=norm_layer)
                for i in range(depth)])
        else:
            self.blocks = attn
        self.norm = norm_layer(self.input_dim)



        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)


    def trsfmr_attn(self, x, q_len):
        """x: B1xB2x(S1+S2)x768"""
        # Pos embedding
        x[:, :q_len, :] = x[:, :q_len, :] + self.pos_embed_q
        x[:, q_len:, :] = x[:, q_len:, :] + self.pos_embed_g

        # seq token
        B = x.shape[0]
        # seq_tokens = self.seq_token.expand(B, -1, -1)  # stole seq_tokens impl from Phil Wang, thanks
        # x = torch.cat((seq_tokens, x), dim=1)
        x = self.pos_drop(x)

        for blk in self.blocks:
            x = blk(x)

        x = self.norm(x)
        return x[:, 0:q_len, :].mean(dim=1)

    def forward(self, querys, gallerys):

        q_size = querys.size()
        q_batch = q_size[0]
        q_len = q_size[1]

        g_size = gallerys.size()
        g_batch = g_size[0]
        g_len = g_size[1]

        # # dim down to 128
        # querys = self.feat_fc(querys.view(q_batch*q_len, -1)).view(q_batch, q_len, -1)
        # gallerys = self.feat_fc(gallerys.view(g_batch*g_len, -1)).view(g_batch, g_len, -1)

        # pos embed
        if self.pos_embed:
            querys = querys + self.pos_embed_q
            gallerys = gallerys + self.pos_embed_g

        # 两两拼接 (bs1 x s1 x d), (bs2, s2, d) -> (bs1, bs2, s1+s2, d)
        querys = querys.unsqueeze(1)
        gallerys = gallerys.unsqueeze(0)

        querys = querys.expand(q_batch, g_batch, q_len, self.input_dim)
        gallerys = gallerys.expand(q_batch, g_batch, g_len, self.input_dim)

        QK = torch.cat([querys, gallerys], dim=2)
        QK = QK.contiguous()
        QK = QK.view(-1, q_len+g_len, self.input_dim)
        QK = self.trsfmr_attn(QK, q_len)

        QK = self.feat_fc(QK)
        QK = QK.view(q_batch, g_batch, self.output_dim)

        return QK




class AttnModel(nn.Module):
    def __init__(self, input_num=768, output_num=128, same_fc=True):  # 2048 ,128
        super(AttnModel, self).__init__()

        self.input_num = input_num
        self.output_num = output_num

        ## attention modules
        if same_fc:
            self.feat_fc = nn.Sequential(nn.Linear(self.input_num, self.output_num),
                                         nn.BatchNorm1d(self.output_num))

            depth = 1; num_heads = 8; mlp_ratio = 4.; qkv_bias = False; qk_scale = None; drop_rate = 0.1; attn_drop_rate = 0.05; drop_path_rate=0.05; norm_layer=nn.LayerNorm
            dpr = [x.item() for x in torch.linspace(0, drop_path_rate, depth)]
            self.blocks = nn.ModuleList([
                Block(
                    dim=self.input_num, num_heads=num_heads, mlp_ratio=mlp_ratio, qkv_bias=qkv_bias, qk_scale=qk_scale,
                    drop=drop_rate, attn_drop=attn_drop_rate, drop_path=dpr[i], norm_layer=norm_layer)
                for i in range(depth)])

            self.selfpooling_model = Self_attn_module(self.input_num, self.output_num, feat_fc=self.feat_fc, loss=[], attn=self.blocks)
            self.crosspooling_model = Cros_attn_module(self.input_num, self.output_num, pos_embed=True, feat_fc=self.feat_fc, attn=self.blocks)

        else:
            self.selfpooling_model = Self_attn_module(self.input_num, self.output_num, loss=[])
            self.crosspooling_model = Cros_attn_module(self.input_num, self.output_num, pos_embed=True)

    def forward(self, x):  # x(bz*sq*128) input(bz*sq*2048)
        xsize = x.size()
        sample_num = xsize[0]  # 64

        if sample_num % 2 != 0:
            raise RuntimeError("the batch size should be even number!")

        seq_len = x.size()[1]  # 10
        # 变成对子
        x = x.view(int(sample_num / 2), 2, seq_len, -1)  # 32*2*10*128

        # 对子里第一个作为probe， 第二个作为gallery
        query_x = x[:, 0, :, :]  # 32*10*128
        query_x = query_x.contiguous()
        gallery_x = x[:, 1, :, :]  # 32*10*128
        gallery_x = gallery_x.contiguous()


        ## self-pooling, aka SAN
        # 32 * 128,  hidden_probe后面没用到
        pooled_query, _ = self.selfpooling_model(query_x, mode='q')
        pooled_gallery, _ = self.selfpooling_model(gallery_x, mode='g')

        ## cross-pooling, aka CAN
        # gallery_x(32*10*128), gallery_input(32*10*2048), pooled_probe(32*128)
        # 用（每个）g来增强（每个）p
        pooled_gallery_2 = self.crosspooling_model(gallery_x, query_x) # 没用到pooled_feature， 实验+1
        # 用p来增强g
        pooled_query_2 = self.crosspooling_model(query_x, gallery_x)
        # 输出32 * 32 * 128: QG两两相互做collaborative attention


        pooled_gallery_2 = pooled_gallery_2.permute(1, 0, 2)

        pooled_query, pooled_gallery = pooled_query.unsqueeze(1), pooled_gallery.unsqueeze(0)
        # print(pooled_query.shape, pooled_gallery_2.shape, pooled_query_2.shape, pooled_gallery.shape)
        # 32*1*128, 32*32*128, 32*32*128, 1*32*128
        return pooled_query, pooled_gallery_2, pooled_query_2, pooled_gallery  # (bz/2) * 128,  (bz/2)*(bz/2)*128




class Vreid_transformer(nn.Module):
    def __init__(self, backbone_name, feat_num=768, feat_num2=128, num_classes=625, drop=0.1, pretrained=True, loss=['softmax']):
        super(Vreid_transformer, self).__init__()
        self.feat_num = feat_num
        self.feat_num2 = feat_num2
        self.dropout = drop
        self.backbone = torchreid.models.build_model(backbone_name, num_classes=num_classes, loss=loss, pretrained=pretrained,)
        self.loss = loss

        # Append new layers
        self.feat = nn.Linear(feat_num, feat_num2)
        self.feat_bn = nn.BatchNorm1d(feat_num2)
        init.kaiming_normal_(self.feat.weight, mode='fan_out')
        init.constant_(self.feat.bias, 0)
        init.constant_(self.feat_bn.weight, 1)
        init.constant_(self.feat_bn.bias, 0)
        if self.dropout > 0:
            self.drop = nn.Dropout(self.dropout)

        # attn & clf models
        self.att_model = AttnModel(self.feat_num, self.feat_num2, same_fc=True)
        self.verifier_model = Verifier(self.feat_num2, class_num=2)



    def forward(self, x=None, extract_feat=False):
        # imgs: (b, s, c, h, w) to x: (b*s, c, h, w)
        img_size = x.size()
        batch_sz = img_size[0]
        seq_len = img_size[1]
        x = x.view(-1, img_size[2], img_size[3], img_size[4])

        # backbone with a clf
        feat, cls_out = self.backbone(x)

        if extract_feat:
            feat = feat.view(batch_sz, seq_len, -1)
            return feat

        x = feat.view(batch_sz, seq_len, -1)
        pooled_probe, pooled_gallery_2, pooled_probe_2, pooled_gallery = self.att_model(x)
        encode_scores = self.verifier_model(pooled_probe, pooled_gallery_2, pooled_probe_2, pooled_gallery)

        encodemat = encode_scores[:, :, 1]

        return feat, cls_out, encodemat


def vridtr_small_resnet26d_224(**kwargs):
    model = Vreid_transformer('vit_small_resnet26d_224', 768, 128, **kwargs)
    return model

def vridtr_small_resnet50d_224(**kwargs):
    model = Vreid_transformer('vit_small_resnet50d_s3_224', 768, 128, **kwargs)
    return model

def vridtr_resnet50(**kwargs):
    model = Vreid_transformer('resnet50', 2048, 128, **kwargs)
    return model


if __name__ == '__main__':
    import torch
    # t = Vreid_transformer('vit_small_resnet26d_224', 768, 128)
    # print(t)
    # o1, o2, o3 = t(torch.rand(8, 2, 3, 224, 224)) #, torch.rand(32, 3, 768)
    # print(o1.shape, o2.shape, o3.shape)

    c = Cros_attn_module()
    print(c(torch.rand(4, 2, 768), torch.rand(3, 3, 768)).shape)

    # a = AttnModel()
    # a(torch.rand(10, 2,768))