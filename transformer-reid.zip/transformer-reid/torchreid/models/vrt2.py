from __future__ import absolute_import

import numpy as np
import torch
import torch.nn as nn
import torch.nn.init as init
from timm.models.layers import trunc_normal_
from timm.models.vision_transformer import Block, Attention, Mlp
import torch.nn.functional as F
import torchreid



class Verifier(nn.Module):
    def __init__(self, feat_num, class_num, drop=0):
        super(Verifier, self).__init__()
        self.feat_num = feat_num
        self.class_num = class_num
        self.drop = drop

        # BN layer
        self.classifierBN = nn.BatchNorm1d(self.feat_num)
        # feat classifeir
        self.classifierlinear = nn.Linear(self.feat_num, self.class_num)
        # dropout_layer
        self.drop = drop
        if self.drop > 0:
            self.droplayer = nn.Dropout(drop)

        init.constant_(self.classifierBN.weight, 1)
        init.constant_(self.classifierBN.bias, 0)

        init.normal_(self.classifierlinear.weight, std=0.001)
        init.constant_(self.classifierlinear.bias, 0)

    def forward(self, probe, gallery2, probe2, gallery):
        S_gallery2 = gallery2.size()
        N_probe = S_gallery2[0]
        N_gallery = S_gallery2[1]
        feat_num = S_gallery2[2]

        # 全部广播成N,N,d
        probe = probe.expand(N_probe, N_gallery, feat_num)
        gallery = gallery.expand(N_probe, N_gallery, feat_num)


        slice0 = 64
        if N_probe < slice0:
            diff1, diff2 = probe - gallery, probe2 - gallery2
            diff = diff1 * diff2
            pg_size = diff.size()
            p_size, g_size = pg_size[0], pg_size[1]
            diff = diff.view(p_size * g_size, -1)
            diff = diff.contiguous()
            diff = self.classifierBN(diff)
            if self.drop > 0:
                diff = self.droplayer(diff)
            cls_encode = self.classifierlinear(diff)
            cls_encode = cls_encode.view(p_size, g_size, -1)

        else:
            iter_time_0 = int(np.floor(N_probe / slice0))
            for i in range(0, iter_time_0):
                before_index_0 = i * slice0
                after_index_0 = (i + 1) * slice0

                probe_tmp = probe[before_index_0:after_index_0, :, :]
                gallery_tmp = gallery[before_index_0:after_index_0, :, :]

                probe2_tmp = probe2[before_index_0:after_index_0, :, :]
                gallery2_tmp = gallery2[before_index_0:after_index_0, :, :]

                diff1_tmp, diff2_tmp = probe_tmp - gallery_tmp, probe2_tmp - gallery2_tmp
                # diff1_tmp = diff1[before_index_0:after_index_0, :, :]
                # diff2_tmp = diff2[before_index_0:after_index_0, :, :]
                diff_tmp = diff1_tmp * diff2_tmp

                pg_size = diff_tmp.size()
                p_size, g_size = pg_size[0], pg_size[1]
                diff_tmp = diff_tmp.view(p_size * g_size, -1)
                diff_tmp = diff_tmp.contiguous()
                diff_tmp = self.classifierBN(diff_tmp)

                if self.drop > 0:
                    diff_tmp = self.droplayer(diff_tmp)
                cls_encode_tmp = self.classifierlinear(diff_tmp)
                cls_encode_tmp = cls_encode_tmp.view(p_size, g_size, -1)
                if i == 0:
                    cls_encode = cls_encode_tmp
                else:
                    cls_encode = torch.cat((cls_encode, cls_encode_tmp), 0)
            before_index_0 = iter_time_0 * slice0
            after_index_0 = N_probe
            if after_index_0 > before_index_0:
                probe_tmp = probe[before_index_0:after_index_0, :, :]
                gallery_tmp = gallery[before_index_0:after_index_0, :, :]
                probe2_tmp = probe2[before_index_0:after_index_0, :, :]
                gallery2_tmp = gallery2[before_index_0:after_index_0, :, :]
                diff1_tmp, diff2_tmp = probe_tmp - gallery_tmp, probe2_tmp - gallery2_tmp
                # diff1_tmp = diff1[before_index_0:after_index_0, :, :]
                # diff2_tmp = diff2[before_index_0:after_index_0, :, :]
                diff_tmp = diff1_tmp * diff2_tmp
                pg_size = diff_tmp.size()
                p_size, g_size = pg_size[0], pg_size[1]
                diff_tmp = diff_tmp.view(p_size * g_size, -1)
                diff_tmp = diff_tmp.contiguous()
                diff_tmp = self.classifierBN(diff_tmp)
                if self.drop > 0:
                    diff_tmp = self.droplayer(diff_tmp)
                cls_encode_tmp = self.classifierlinear(diff_tmp)
                cls_encode_tmp = cls_encode_tmp.view(p_size, g_size, -1)
                cls_encode = torch.cat((cls_encode, cls_encode_tmp), 0)

        return cls_encode




class Self_attn_module(nn.Module):
    """
    gallery_x(B*S*768), pooled_probe(B*768) -> B X B x 128
    i.e. for each seq A's frame-lv feats and a pooled seq B's seq-lv feat, the model outputs a pooled cross-attn feat for seq A
    """
    def __init__(self, dim=128, num_heads=8, depth=1, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.05, drop_rate=0.1, norm_layer=nn.LayerNorm, loss=['softmax'], num_classes=650,  attn=None
                 ):
        super(Self_attn_module, self).__init__()
        self.loss = loss
        self.num_classes = num_classes

        self.dim = dim
        self.pos_drop = nn.Dropout(p=drop_rate)
        self.blocks = nn.ModuleList([
                Block(dim=dim, num_heads=num_heads) for i in range(depth)
                ])
        self.norm = norm_layer(self.dim)
        # self.attn = Attention(self.dim, num_heads, qkv_bias, qk_scale, attn_drop, proj_drop)
        # self.norm = norm_layer(self.dim)
        # Classifier head
        # if 'softmax' in self.loss:
        #     self.head = nn.Linear(self.output_dim, num_classes) if num_classes > 0 else nn.Identity()

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)


    def self_attn(self, x, mode):
        """x: BxSx128"""
        # if self.pos_embed and mode == 'q':
        #     x = x + self.pos_embed_q
        # elif self.pos_embed and mode == 'g':
        #     x = x + self.pos_embed_g

        x = self.pos_drop(x)
        # print(x.shape)
        # x = self.attn(x)
        for blk in self.blocks:
            x = blk(x)
        x = self.norm(x)
        return x

    def forward(self, feat1, feat2, mode='q'):
        # bs, l = feat1.shape[0], feat1.shape[1]
        feat1 = self.self_attn(feat1, mode)
        feat1 = F.softmax(feat1, dim=1)
        feat2 = (feat1 * feat2).sum(dim=1)
        # print('sf', feat2.shape)
        return feat2, 0




class CrossAttention(nn.Module):
    """
    输入bs1x1x128的作为q, bs2xlx128作为kv
    输出bs2x1x128作为pooled v
    """
    def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.05, ):
        super().__init__()
        self.num_heads = num_heads
        head_dim = dim // num_heads
        # NOTE scale factor was wrong in my original version, can set manually to be compat with prev weights
        self.scale = qk_scale or head_dim ** -0.5

        self.kv = nn.Linear(dim, dim * 2, bias=qkv_bias)
        self.q = nn.Linear(dim, dim, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

    def forward(self, q, x):
        # print('input', q.shape, x.shape)
        B, N, C = x.shape  # bs, num_token, num_dim
        # print(q.shape, x.shape)
        q = self.q(q).reshape(q.shape[0], q.shape[1], self.num_heads, C // self.num_heads).permute(0, 2, 1, 3).expand(-1, -1, N, -1) # 复制num_token份
        # print(q.shape)
        kv = self.kv(x).reshape(B, N, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)  # bs, num_token, 3(qkv) , num_head, head_dim -> 3(qkv), bs, num_head, num_token, head_dim
        k, v = kv[0], kv[1]  # bs x nh x nt x hd

        # print("qkv", q.shape, k.shape, v.shape)

        attn = (q @ k.transpose(-2, -1)) * self.scale  # attn: (1xd) rather than (dxd)
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        x = (attn @ v).transpose(1, 2).reshape(B, N, C)  #

        x = self.proj(x)
        x = self.proj_drop(x)
        return x



class CABlock(nn.Module):

    def __init__(self, dim, num_heads, mlp_ratio=4., qkv_bias=False, qk_scale=None, drop=0., attn_drop=0.,
                 drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm):
        super().__init__()
        self.norm1 = norm_layer(dim)
        self.attn = CrossAttention(
            dim, num_heads=num_heads, qkv_bias=qkv_bias, qk_scale=qk_scale, attn_drop=attn_drop, proj_drop=drop)
        # NOTE: drop path for stochastic depth, we shall see if this is better than dropout here
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(dim)
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)

    def forward(self, q, x):
        x = x + self.drop_path(self.attn(q, self.norm1(x)))
        x = x + self.drop_path(self.mlp(self.norm2(x)))
        return x



class Cros_attn_module(nn.Module):
    def __init__(self, dim=128, num_heads=4, depth=1, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0., drop_rate=0.1, norm_layer=nn.LayerNorm, feat_fc=None, attn=None
                 ):
        super(Cros_attn_module, self).__init__()
        self.dim = dim

        # pos dropout
        self.pos_drop = nn.Dropout(p=drop_rate)
        self.cablock = CABlock(self.dim, num_heads, qkv_bias=qkv_bias, qk_scale=qk_scale, drop=drop_rate, attn_drop=attn_drop,)
        # self.cablock2 = nn.ModuleList([Block(dim=dim, num_heads=num_heads) for i in range(depth-1)])

        self.norm = norm_layer(self.dim)

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)

    def cross_attn(self, querys, gallerys):
        """
        Inputs:
            querys: B1xB2， 1， 128
            gallerys: B1xB2， g_len， 128

        Outputs:

        """
        querys = self.pos_drop(querys)
        gallerys = self.pos_drop(gallerys)

        gallerys = self.cablock(querys, gallerys)
        # for blk in self.cablock2:
        #     gallerys = blk(gallerys)
        gallerys = self.norm(gallerys)
        return gallerys

    def forward(self, g_feat1, g_feat2, pooled_q):
        """
        输入: g_feat1: B2 x S2 x 128,
             g_feat2: B2 x S2 x 128，
             pooled_q: B1 x 1 x 128

        g_feat1与pooled_q做cross attn后得到
        输出B1xB2x128 (temporal pooling)
        """
        # print('cs_start', g_feat1.shape, g_feat2.shape, pooled_q.shape)
        pooled_q = pooled_q.unsqueeze(1)
        q_size = pooled_q.size()
        q_batch = q_size[0]
        q_len = q_size[1]

        g_size = g_feat1.size()
        g_batch = g_size[0]
        g_len = g_size[1]

        # 两两拼接 (bs1 x s1 x d), (bs2, s2, d) -> (bs1, bs2, s1+s2, d)
        pooled_q = pooled_q.unsqueeze(1)
        g_feat1 = g_feat1.unsqueeze(0)
        g_feat2 = g_feat2.unsqueeze(0)

        pooled_q = pooled_q.expand(q_batch, g_batch, q_len, self.dim).contiguous().view(-1, q_len, self.dim)
        g_feat1 = g_feat1.expand(q_batch, g_batch, g_len, self.dim).contiguous().view(-1, g_len, self.dim)
        g_feat2 = g_feat2.expand(q_batch, g_batch, g_len, self.dim).contiguous().view(-1, g_len, self.dim)

        # print(self.cross_attn(pooled_q, g_feat1).shape)
        g_feat1 = self.cross_attn(pooled_q, g_feat1) * g_feat1  # pooled weight .view(q_batch, g_batch, self.dim)    b1*b2, 1, dim,  b1*b2, g_len, dim
        g_feat1 = F.softmax(g_feat1, dim=1)   # 做softmax能突出重要特征， 抑制不重要特征
        g_feat2 = (g_feat1 * g_feat2).sum(dim=1).view(q_batch, g_batch, self.dim)

        return g_feat2



class AttnModel(nn.Module):
    def __init__(self, input_num=128, output_num=128, same_attn=False):  # 2048 ,128
        super(AttnModel, self).__init__()

        self.input_num = input_num
        self.output_num = output_num

        ## attention modules
        if same_attn:
            self.attn = Attention(
            dim, num_heads=num_heads, qkv_bias=qkv_bias, qk_scale=qk_scale, attn_drop=attn_drop, proj_drop=drop)

            # self.selfpooling_model = Self_attn_module()
            # self.crosspooling_model = Cros_attn_module()
        else:
            self.selfpooling_model = Self_attn_module(output_num)
            self.crosspooling_model = Cros_attn_module(output_num)

    def forward(self, x1, x2):  # x(bz*sq*128) input(bz*sq*2048)
        ## batch内分query与gallery
        xsize = x1.size()
        sample_num = xsize[0]  # 64
        if sample_num % 2 != 0:
            raise RuntimeError("the batch size should be even number!")
        seq_len = x1.size()[1]  # 10
        # 变成对子
        x1 = x1.view(int(sample_num / 2), 2, seq_len, self.output_num)  # 32*2*10*128
        x2 = x2.view(int(sample_num / 2), 2, seq_len, self.output_num)  # 32*2*10*128

        # 对子里第一个作为probe， 第二个作为gallery
        query_x1 = x1[:, 0, :, :]  # 32*10*128
        query_x1 = query_x1.contiguous()
        gallery_x1 = x1[:, 1, :, :]  # 32*10*128
        gallery_x1 = gallery_x1.contiguous()

        query_x2 = x2[:, 0, :, :]  # 32*10*128
        query_x2 = query_x2.contiguous()
        gallery_x2 = x2[:, 1, :, :]  # 32*10*128
        gallery_x2 = gallery_x2.contiguous()

        ## self-pooling, aka SAN
        # 32 * 128,  hidden_probe后面没用到
        pooled_query, _ = self.selfpooling_model(query_x1, query_x2, mode='q')
        pooled_gallery, _ = self.selfpooling_model(gallery_x1, gallery_x2, mode='g')

        # print('pooled', pooled_query.shape, pooled_gallery.shape)

        ## cross-pooling, aka CAN
        # gallery_x(32*10*128), gallery_input(32*10*2048), pooled_probe(32*128)
        # 用（每个）g来增强（每个）p
        pooled_gallery_2 = self.crosspooling_model(gallery_x1, gallery_x2, pooled_query) # 没用到pooled_feature， 实验+1
        # 用p来增强g
        pooled_query_2 = self.crosspooling_model(query_x1, query_x2, pooled_gallery)
        # 输出32 * 32 * 128: QG两两相互做collaborative attention

        pooled_gallery_2 = pooled_gallery_2.permute(1, 0, 2)
        pooled_query, pooled_gallery = pooled_query.unsqueeze(1), pooled_gallery.unsqueeze(0)
        # print(pooled_query.shape, pooled_gallery_2.shape, pooled_query_2.shape, pooled_gallery.shape)
        # 32*1*128, 32*32*128, 32*32*128, 1*32*128
        return pooled_query, pooled_gallery_2, pooled_query_2, pooled_gallery  # (bz/2) * 128,  (bz/2)*(bz/2)*128




class Vrt2(nn.Module):
    def __init__(self, backbone_name, feat_num=768, feat_num2=128, num_classes=625, drop=0.1, pretrained=True, loss=['softmax']):
        super(Vrt2, self).__init__()
        self.feat_num = feat_num
        self.feat_num2 = feat_num2
        self.dropout = drop
        self.backbone = torchreid.models.build_model(backbone_name, num_classes=num_classes, loss=loss, pretrained=pretrained,)
        self.loss = loss

        # Append new layers
        self.fc1 = nn.Sequential(
            nn.Linear(feat_num, feat_num2),
            nn.BatchNorm1d(feat_num2),
            # nn.LeakyReLU(),
            nn.Dropout(self.dropout),
            # nn.Linear(feat_num2, feat_num2),
            # nn.BatchNorm1d(feat_num2),
            # nn.LeakyReLU(),
        )

        self.fc2 = nn.Sequential(
            nn.Linear(feat_num, feat_num2),
            nn.BatchNorm1d(feat_num2),
            # nn.LeakyReLU(),
            nn.Dropout(self.dropout),
            # nn.Linear(feat_num2, feat_num2),
            # nn.BatchNorm1d(feat_num2),
            # nn.LeakyReLU(),
            )

        self.sa_head = nn.Linear(feat_num2, num_classes)

        if self.dropout > 0:
            self.drop = nn.Dropout(self.dropout)

        # attn & clf models
        self.att_model = AttnModel(self.feat_num, self.feat_num2)
        self.verifier_model = Verifier(self.feat_num2, class_num=2)

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)

    def forward(self, x=None, extract_feat=False):
        # imgs: (b, s, c, h, w) to x: (b*s, c, h, w)
        img_size = x.size()
        batch_sz = img_size[0]
        seq_len = img_size[1]
        x = x.view(-1, img_size[2], img_size[3], img_size[4])

        # backbone with a clf
        feat, cls_out, feat2 = self.backbone(x)

        feat = self.drop(feat)

        # feat1用于计算权重，给feat2加权，在时序上加权融合后的feat2作为最终的seq-level feat参与相似度计算
        feat1 = self.fc1(feat)
        feat2 = self.fc2(feat2)

        feat1 = feat1.view(batch_sz, seq_len, -1)
        feat2 = feat2.view(batch_sz, seq_len, -1)
        # print(feat1.shape, feat2.shape)
        if extract_feat:
            return feat1, feat2

        # 训练时，一半batch作为q，另一半作为g
        pooled_query, pooled_gallery_2, pooled_query_2, pooled_gallery = self.att_model(feat1, feat2)
        # print(pooled_probe.shape, pooled_gallery_2.shape, pooled_probe_2.shape, pooled_gallery.shape)
        encode_scores = self.verifier_model(pooled_query, pooled_gallery_2, pooled_query_2, pooled_gallery)
        encodemat = encode_scores[:, :, 1]

        sa_out = torch.cat([pooled_query, pooled_gallery.squeeze(0).unsqueeze(1)], dim=1).contiguous()
        sa_out = sa_out.view(-1, self.feat_num2)
        sa_clsout = self.sa_head(sa_out)
        # print(sa_clsout.shape, cls_out.shape)

        return sa_clsout, encodemat, sa_out, cls_out


def Vrt2_vit26d(**kwargs):
    model = Vrt2('vit_small_resnet26d_224', 768, 128, **kwargs)
    return model

def Vrt2_vit50d(**kwargs):
    model = Vrt2('vit_small_resnet50d_s3_224', 768, 128, **kwargs)
    return model

def Vrt2_resnet50(**kwargs):
    model = Vrt2('resnet50', 2048, 128, **kwargs)
    return model


if __name__ == '__main__':
    import torch
    t = Vrt2('vit_small_resnet26d_224', 768, 128).cuda()
    # print(t)
    o1, o2, o3, _ = t(torch.rand(32, 3, 3, 224, 224).cuda()) #, torch.rand(32, 3, 768)
    print(o1.shape, o2.shape, o3.shape)

    # c = CrossAttention(128)
    # print(c(torch.rand(1, 1, 128), torch.rand(2, 3, 128)).shape)

    # a = Self_attn_module()
    # print(a(torch.rand(10, 2, 128), torch.rand(10, 2, 128)))