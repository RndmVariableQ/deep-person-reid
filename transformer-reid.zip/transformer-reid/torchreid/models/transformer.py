import torchreid
import torch
import timm
from timm.models.vision_transformer import *

def deit_base_patch16_224(num_classes, loss='softmax', pretrained=True, **kwargs):
    model = torch.hub.load('facebookresearch/deit:main', 'deit_base_patch16_224',
                           num_classes=num_classes,
                           loss=loss,
                           pretrained=pretrained)
    return model


def deit_small_patch16_224(num_classes, loss='softmax', pretrained=True, **kwargs):
    model = torch.hub.load('facebookresearch/deit:main', 'deit_small_patch16_224',
                           num_classes=num_classes,
                           loss=loss,
                           pretrained=pretrained)
    return model


def deit_tiny_patch16_224(num_classes, loss='softmax', pretrained=True, **kwargs):
    model = torch.hub.load('facebookresearch/deit:main', 'deit_tiny_patch16_224',
                           num_classes=num_classes,
                           loss=loss,
                           pretrained=pretrained,
                           **kwargs)
    return model

def vit_base_resnet26d_224(num_classes, loss='softmax', pretrained=True, **kwargs):
    model = timm.models.vit_base_resnet26d_224(num_classes=num_classes,
                                               loss=loss,
                                               pretrained=pretrained)
    return model


def vit_small_resnet26d_224(num_classes, loss='softmax', pretrained=True, **kwargs):
    model = timm.models.vit_small_resnet26d_224(num_classes=num_classes,
                                               loss=loss,
                                               pretrained=pretrained)
    return model


def vit_small_resnet50d_s3_224(num_classes, loss='softmax', pretrained=True, **kwargs):
    model = timm.models.vit_small_resnet50d_s3_224(num_classes=num_classes,
                                               loss=loss,
                                               pretrained=pretrained)
    return model




if __name__ == '__main__':
    model = vit12(loss='softmax',
                  image_size=(256, 128),
                  num_classes=1000,
                  num_layers=12,
    )
    x = torch.randn((2, 3, 256, 128))
    out = model(x)

    state_dict = model.state_dict()

    for key, value in state_dict.items():
        print("{}: {}".format(key, value.shape))