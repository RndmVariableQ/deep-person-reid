from __future__ import absolute_import

import torch
import torch.nn.init as init
import numpy as np
from torch import nn
from torch.nn import functional as F
import torch.nn.init as init
from torchreid.models.transformer import *
import torchreid
from timm.models.vision_transformer import Block
from timm.models.layers import DropPath, to_2tuple, trunc_normal_
from torch.nn.functional import normalize




class TSA(nn.Module):
    def __init__(self, backbone_name, feat_num=768, feat_num2=512, depth=4, num_classes=625, drop=0.1, pretrained=True):
        super(TSA, self).__init__()
        self.feat_num = feat_num
        self.dropout = drop
        self.backbone = torchreid.models.build_model(backbone_name, num_classes=num_classes, pretrained=pretrained,)
        if self.dropout > 0:
            self.drop = nn.Dropout(self.dropout)

        self.fc = nn.Sequential(
            nn.Linear(feat_num, feat_num2),
            nn.BatchNorm1d(feat_num2),
        )

        self.blocks = nn.ModuleList([
            Block(feat_num2, 8, drop=0.1, attn_drop=0.05,)
            for i in range(depth)])
        self.norm = nn.LayerNorm(feat_num2)
        self.avgpool = nn.AdaptiveAvgPool2d(output_size=(1, feat_num2))
        self.clf = nn.Linear(feat_num2, num_classes)

        self.branch1 = nn.Sequential(
            nn.Linear(feat_num, feat_num2),
            nn.BatchNorm1d(feat_num2),
            # nn.LeakyReLU(),
            # nn.Dropout(self.dropout),
            # nn.Linear(feat_num2, feat_num2),
            # nn.BatchNorm1d(feat_num2),
            # nn.LeakyReLU(),
        )

        self.branch2 = nn.Sequential(
            nn.Linear(feat_num, feat_num2),
            nn.BatchNorm1d(feat_num2),
            # nn.LeakyReLU(),
            # nn.Dropout(self.dropout),
            # nn.Linear(feat_num2, feat_num2),
            # nn.BatchNorm1d(feat_num2),
            # nn.LeakyReLU(),
            )

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)

    def forward(self, x=None, extract_feat=False):
        # imgs: (b, s, c, h, w) to x: (b*s, c, h, w)

        img_size = x.size()
        batch_sz = img_size[0]
        seq_len = img_size[1]
        x = x.view(-1, img_size[2], img_size[3], img_size[4])


        # backbone with a clf
        feat, _ = self.backbone(x)
        feat1 = self.branch1(feat)
        feat2 = self.branch2(feat)

        feat1 = self.drop(feat1)
        feat2 = self.drop(feat2)

        feat1 = feat1.view(batch_sz, seq_len, -1)  # b, s, d
        feat2 = feat2.view(batch_sz, seq_len, -1)

        for blk in self.blocks:
            feat1 = blk(feat1)
        feat1 = self.norm(feat1)

        # weight = feat1.mean(dim=1).unsqueeze(1)
        # weight = F.softmax(F.cosine_similarity(weight, feat2, dim=2), dim=1).unsqueeze(-1)

        feat = feat1 * feat2
        feat = self.avgpool(feat) # feat.mean(dim=1) #
        x = self.clf(feat)
        feat = normalize(feat, p=2, dim=2)
        # temporal self attention

        return x.squeeze(), feat.squeeze()



def tsa_resnet50(**kwargs):
    model = TSA(backbone_name='resnet50', feat_num=2048, **kwargs)
    return model


if __name__ == '__main__':
    import torch
    t = tsa_resnet50()
    print(t(torch.rand(3,4,3,224,224))[0].shape)