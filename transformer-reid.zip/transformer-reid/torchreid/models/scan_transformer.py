from __future__ import absolute_import
import torch
import torch.nn.init as init
import numpy as np
from torch import nn
from torch.nn import functional as F
from torchreid.models.selfpoolingdir import SelfPoolingDir
from torchreid.models.crosspoolingdir import CrossPoolingDir
import torch.nn.init as init
from torchreid.models.transformer import *
import torchreid

class Classifier(nn.Module):
    def __init__(self, feat_num, class_num, drop=0):
        super(Classifier, self).__init__()
        self.feat_num = feat_num
        self.class_num = class_num
        self.drop = drop

        # BN layer
        self.classifierBN = nn.BatchNorm1d(self.feat_num)
        # feat classifeir
        self.classifierlinear = nn.Linear(self.feat_num, self.class_num)
        # dropout_layer
        self.drop = drop
        if self.drop > 0:
            self.droplayer = nn.Dropout(drop)

        init.constant_(self.classifierBN.weight, 1)
        init.constant_(self.classifierBN.bias, 0)

        init.normal_(self.classifierlinear.weight, std=0.001)
        init.constant_(self.classifierlinear.bias, 0)

    def forward(self, probe, gallery2, probe2, gallery):
        S_gallery2 = gallery2.size()
        N_probe = S_gallery2[0]
        N_gallery = S_gallery2[1]
        feat_num = S_gallery2[2]

        # 全部广播成N,N,d
        probe = probe.expand(N_probe, N_gallery, feat_num)
        gallery = gallery.expand(N_probe, N_gallery, feat_num)


        slice0 = 64
        if N_probe < slice0:
            diff1, diff2 = probe - gallery, probe2 - gallery2
            diff = diff1 * diff2
            pg_size = diff.size()
            p_size, g_size = pg_size[0], pg_size[1]
            diff = diff.view(p_size * g_size, -1)
            diff = diff.contiguous()
            diff = self.classifierBN(diff)
            if self.drop > 0:
                diff = self.droplayer(diff)
            cls_encode = self.classifierlinear(diff)
            cls_encode = cls_encode.view(p_size, g_size, -1)

        else:
            iter_time_0 = int(np.floor(N_probe / slice0))
            for i in range(0, iter_time_0):
                before_index_0 = i * slice0
                after_index_0 = (i + 1) * slice0

                probe_tmp = probe[before_index_0:after_index_0, :, :]
                gallery_tmp = gallery[before_index_0:after_index_0, :, :]

                probe2_tmp = probe2[before_index_0:after_index_0, :, :]
                gallery2_tmp = gallery2[before_index_0:after_index_0, :, :]

                diff1_tmp, diff2_tmp = probe_tmp - gallery_tmp, probe2_tmp - gallery2_tmp
                # diff1_tmp = diff1[before_index_0:after_index_0, :, :]
                # diff2_tmp = diff2[before_index_0:after_index_0, :, :]
                diff_tmp = diff1_tmp * diff2_tmp

                pg_size = diff_tmp.size()
                p_size, g_size = pg_size[0], pg_size[1]
                diff_tmp = diff_tmp.view(p_size * g_size, -1)
                diff_tmp = diff_tmp.contiguous()
                diff_tmp = self.classifierBN(diff_tmp)

                if self.drop > 0:
                    diff_tmp = self.droplayer(diff_tmp)
                cls_encode_tmp = self.classifierlinear(diff_tmp)
                cls_encode_tmp = cls_encode_tmp.view(p_size, g_size, -1)
                if i == 0:
                    cls_encode = cls_encode_tmp
                else:
                    cls_encode = torch.cat((cls_encode, cls_encode_tmp), 0)
            before_index_0 = iter_time_0 * slice0
            after_index_0 = N_probe
            if after_index_0 > before_index_0:
                probe_tmp = probe[before_index_0:after_index_0, :, :]
                gallery_tmp = gallery[before_index_0:after_index_0, :, :]
                probe2_tmp = probe2[before_index_0:after_index_0, :, :]
                gallery2_tmp = gallery2[before_index_0:after_index_0, :, :]
                diff1_tmp, diff2_tmp = probe_tmp - gallery_tmp, probe2_tmp - gallery2_tmp
                # diff1_tmp = diff1[before_index_0:after_index_0, :, :]
                # diff2_tmp = diff2[before_index_0:after_index_0, :, :]
                diff_tmp = diff1_tmp * diff2_tmp
                pg_size = diff_tmp.size()
                p_size, g_size = pg_size[0], pg_size[1]
                diff_tmp = diff_tmp.view(p_size * g_size, -1)
                diff_tmp = diff_tmp.contiguous()
                diff_tmp = self.classifierBN(diff_tmp)
                if self.drop > 0:
                    diff_tmp = self.droplayer(diff_tmp)
                cls_encode_tmp = self.classifierlinear(diff_tmp)
                cls_encode_tmp = cls_encode_tmp.view(p_size, g_size, -1)
                cls_encode = torch.cat((cls_encode, cls_encode_tmp), 0)

        return cls_encode


class AttModuleDir(nn.Module):

    def __init__(self, input_num=2048, output_num=128, same_fc=True):  # 2048 ,128
        super(AttModuleDir, self).__init__()

        self.input_num = input_num
        self.output_num = output_num

        ## attention modules
        if same_fc:
            self.feat_fc = nn.Sequential(nn.Linear(self.input_num, self.output_num),
                                         nn.BatchNorm1d(self.output_num))
            for m in self.feat_fc.modules():
                if isinstance(m, nn.Linear):
                    init.kaiming_normal_(m.weight, mode='fan_out')
                    init.constant_(m.bias, 0)
                elif isinstance(m, nn.BatchNorm1d):
                    init.constant_(m.weight, 1)
                    init.constant_(m.bias, 0)
                else:
                    pass
                    #print(type(m))

            self.selfpooling_model = SelfPoolingDir(self.input_num, self.output_num, feat_fc=self.feat_fc)
            self.crosspooling_model = CrossPoolingDir(self.input_num, self.output_num, feat_fc=self.feat_fc)
        else:
            self.selfpooling_model = SelfPoolingDir(self.input_num, self.output_num)
            self.crosspooling_model = CrossPoolingDir(self.input_num, self.output_num)

    def forward(self, x, inputs):  # x(bz*sq*128) input(bz*sq*2048)
        xsize = x.size()
        sample_num = xsize[0]  # 64

        if sample_num % 2 != 0:
            raise RuntimeError("the batch size should be even number!")

        seq_len = x.size()[1]  # 10
        # 变成对子
        x = x.view(int(sample_num / 2), 2, seq_len, -1)  # 32*2*10*128
        inputs = inputs.view(int(sample_num / 2), 2, seq_len, -1)  # 32*2*10*2048

        # 对子里第一个作为probe， 第二个作为gallery
        probe_x = x[:, 0, :, :]  # 32*10*128
        probe_x = probe_x.contiguous()
        gallery_x = x[:, 1, :, :]  # 32*10*128
        gallery_x = gallery_x.contiguous()

        probe_input = inputs[:, 0, :, :]  # 32*10*2048
        probe_input = probe_input.contiguous()
        gallery_input = inputs[:, 1, :, :]  # 32*10*2048
        gallery_input = gallery_input.contiguous()


        ## self-pooling, aka SAN
        # 32 * 128,  hidden_probe后面没用到 (32x10x128), (32x10x2048) -> (32x128)
        pooled_probe, hidden_probe = self.selfpooling_model(probe_x, probe_input)
        print(pooled_probe.shape)
        pooled_gallery, hidden_gallery = self.selfpooling_model(gallery_x, gallery_input)



        ## cross-pooling, aka CAN
        # gallery_x(32*10*128), gallery_input(32*10*2048), pooled_probe(32*128) -> 32x32x128
        # 用（每个）g来增强（每个）p
        pooled_gallery_2 = self.crosspooling_model(gallery_x, gallery_input, pooled_probe)
        # 用p来增强g
        pooled_probe_2 = self.crosspooling_model(probe_x, probe_input, pooled_gallery)
        # 32 * 32 * 128: QG两两相互做collaborative attention

        pooled_probe_2 = pooled_probe_2.permute(1, 0, 2)
        pooled_probe, pooled_gallery = pooled_probe.unsqueeze(1), pooled_gallery.unsqueeze(0)
        # 32*1*128, 32*32*128, 32*32*128, 1*32*128
        return pooled_probe, pooled_gallery_2, pooled_probe_2, pooled_gallery  # (bz/2) * 128,  (bz/2)*(bz/2)*128



class SCAN_transformer(nn.Module):
    def __init__(self, backbone_name, feat_num=768, feat_num2=128, num_classes=625, drop=0.1):
        super(SCAN_transformer, self).__init__()
        self.feat_num = feat_num
        self.feat_num2 = feat_num2
        self.dropout = drop
        self.backbone = torchreid.models.build_model(backbone_name, num_classes=0,  loss='oim', pretrained=True)

        # Append new layers
        self.feat = nn.Linear(feat_num, feat_num2)
        self.feat_bn = nn.BatchNorm1d(feat_num2)
        init.kaiming_normal_(self.feat.weight, mode='fan_out')
        init.constant_(self.feat.bias, 0)
        init.constant_(self.feat_bn.weight, 1)
        init.constant_(self.feat_bn.bias, 0)
        if self.dropout > 0:
            self.drop = nn.Dropout(self.dropout)


        # attn & clf models
        self.att_model = AttModuleDir(feat_num, feat_num2)
        self.classifier_model = Classifier(feat_num2, class_num=2)



    def forward(self, imgs=None, extract_feat=False):
        # imgs: (b, s, c, h, w)
        img_size = imgs.size()
        batch_sz = img_size[0]
        seq_len = img_size[1]
        imgs = imgs.view(-1, img_size[2], img_size[3], img_size[4])

        # x: (b*s, c, h, w)
        x = imgs

        if self.training:
            x, y = self.backbone(x)
        else:
            x = self.backbone(x)

        raw = x.view(batch_sz, seq_len, -1)

        # embedding
        x = self.feat(x)
        x = self.feat_bn(x)
        if self.dropout > 0:
            x = self.drop(x)
        x = x / x.norm(2, 1).unsqueeze(1).expand_as(x)

        feat = x.view(batch_sz, seq_len, -1)
        if extract_feat:
            return feat, raw

        # x: feat
        # raw: featX
        x = x.view(batch_sz, seq_len, -1)
        pooled_probe, pooled_gallery_2, pooled_probe_2, pooled_gallery = self.att_model(x, raw)
        encode_scores = self.classifier_model(pooled_probe, pooled_gallery_2, pooled_probe_2, pooled_gallery)

        encodemat = encode_scores[:, :, 1]
        # encodemat = F.softmax(encode_scores, dim=2)
        # encodemat = encodemat[:, :, 1]

        if self.classifier:
            return feat, encodemat, raw, y
        else:
            return feat, encodemat, raw


def scan_transformer_small_resnet26d(num_classes, loss='softmax', pretrained=True, **kwargs):
    model = SCAN_transformer(backbone_name='vit_small_resnet26d_224', feat_num=768, feat_num2=128, **kwargs)
    return model


def scan_transformer_small_resnet50d(num_classes, loss='softmax', pretrained=True, **kwargs):
    model = SCAN_transformer(backbone_name='vit_small_resnet50d_s3_224', feat_num=768, feat_num2=128)
    return model


def scan_transformer_resnet50(num_classes, loss='softmax', pretrained=True, **kwargs):
    model = SCAN_transformer(backbone_name='resnet50', feat_num=2048, feat_num2=128)
    return model

def scan_deit_tiny_patch16_224(num_classes, loss='softmax', pretrained=True, **kwargs):
    model = SCAN_transformer(backbone_name='deit_tiny_patch16_224', feat_num=768, feat_num2=128, classifier=True)
    return model



if __name__ == '__main__':
    import torch as t
    c = scan_transformer_small_resnet26d(0)
    # # 32*1*128, 32*32*128, 32*32*128, 1*32*128
    a = c(t.rand(8,3,3,224,224))
    # print(a[0].shape, a[1].shape)

    # probe_x = torch.rand(4,2,128)
    # probe_input = torch.rand(4,2,2048)
    # gallery_x = torch.rand(3,5,128)
    # gallery_input = torch.rand(3,5,2048)
    # a = AttModuleDir()
    # z,x,c,v = a(torch.rand(4,1,128), torch.rand(4,1,2048))
    # print(z.shape, x.shape, c.shape, v.shape)