from __future__ import print_function, absolute_import
import time
import torch
from torch.autograd import Variable
from utils.meters import AverageMeter
from utils import to_numpy
from .eva_functions import cmc, mean_ap
import numpy as np
import torch.nn.functional as F
CUDA_LAUNCH_BLOCKING=1

def evaluate_seq(distmat, query_pids, query_camids, gallery_pids, gallery_camids, cmc_topk=(1, 5, 10, 20)):

    query_ids = np.array(query_pids)
    gallery_ids = np.array(gallery_pids)
    query_cams = np.array(query_camids)
    gallery_cams = np.array(gallery_camids)

    ##
    mAP = mean_ap(distmat, query_ids, gallery_ids, query_cams, gallery_cams)
    print('Mean AP: {:4.1%}'.format(mAP))

    cmc_configs = {
        # 'allshots': dict(separate_camera_set=False,
        #                  single_gallery_shot=False,
        #                  first_match_break=False),
        # 'cuhk03': dict(separate_camera_set=True,
        #                single_gallery_shot=True,
        #                first_match_break=False),
        'market1501': dict(separate_camera_set=False,
                           single_gallery_shot=False,
                           first_match_break=True)}
    cmc_scores = {name: cmc(distmat, query_ids, gallery_ids,
                            query_cams, gallery_cams, **params)
                  for name, params in cmc_configs.items()}

    print('CMC Scores{:>12}' # {:>12}{:>12}
          .format('market1501')) #'allshots', 'cuhk03',
    for k in cmc_topk:
        print('  top-{:<4}{:12.1%}' # {:12.1%}{:12.1%}
              .format(k,  # cmc_scores['allshots'][k - 1], cmc_scores['cuhk03'][k - 1],
                      cmc_scores['market1501'][k - 1]))

    # Use the allshots cmc top-1 score for validation criterion
    top1 = cmc_scores['market1501'][0]
    top5 = cmc_scores['market1501'][4]
    top10 = cmc_scores['market1501'][9]
    top20 = cmc_scores['market1501'][19]

    return mAP, top1, top5, top10, top20


class ATTEvaluator(object):

    def __init__(self, model, criterion):
        super(ATTEvaluator, self).__init__()
        self.cnn_model = model
        self.att_model = model.att_model
        self.verifier_model = model.verifier_model.cpu()
        # self.mode = mode
        self.criterion = criterion

    @torch.no_grad()
    def extract_feature(self, data_loader, full_seq=False):
        print_freq = 10
        self.cnn_model.eval()
        self.att_model.eval()

        batch_time = AverageMeter()
        data_time = AverageMeter()
        end = time.time()

        # allfeatures = 0
        # allfeatures_raw = 0

        PIDS = []
        CAMIDS = []
        TRANUM = []
        allfeat1 = []
        allfeat2 = []
        i_last = 0

        for i, data in enumerate(data_loader):
            data_time.update(time.time() - end)
            # imgs = Variable(imgs, volatile=True)
            imgs = data['img'].cuda()
            pids = data['pid']
            camids = data['camid']

            PIDS.append(pids)
            CAMIDS.append(camids)
            TRANUM.append(imgs.shape[0])

            feat1, feat2 = self.cnn_model(imgs, True) #, flows, self.mode)
            allfeat1.append(feat1.data.cpu())
            allfeat2.append(feat2.data.cpu())

            # if full_seq and ((i+1) % 2000 == 0 or i+1) >= 9330:
            #     print(i)
            #     print(PIDS, CAMIDS)
            #     torch.save(allfeat1, '/data/PycharmProjects/deep-person-reid/log/vrt2/vit50_exp1/eval/g_feat1_{}-{}.pt'.format(i_last, i))
            #     torch.save(allfeat2, '/data/PycharmProjects/deep-person-reid/log/vrt2/vit50_exp1/eval/g_feat2_{}-{}.pt'.format(i_last, i))
            #
            #     i_last = i
            #     del allfeat1, allfeat2
            #     allfeat1 = []
            #     allfeat2 = []
                # PIDS = []
                # CAMIDS = []
                # TRANUM = []

            batch_time.update(time.time() - end)
            end = time.time()

            if (i + 1) % print_freq == 0:
                print('Extract Features: [{}/{}]\t'
                      'Time {:.3f} ({:.3f})\t'
                      'Data {:.3f} ({:.3f})\t'
                      .format(i + 1, len(data_loader),
                              batch_time.val, batch_time.avg,
                              data_time.val, data_time.avg))


        # if not full_seq:
        allfeat1 = torch.cat(allfeat1, 0)
        allfeat2 = torch.cat(allfeat2, 0)
        allpids = torch.cat(PIDS, 0)
        allcamids = torch.cat(CAMIDS, 0)
        return allfeat1, allfeat2, allpids, allcamids, TRANUM



    @torch.no_grad()
    def evaluate(self, query_loader, gallery_loader):

        # print(len(query_loader), query_loader.batch_size)
        self.cnn_model.eval()
        self.att_model.eval()
        self.verifier_model.eval()

        query_feat1, query_feat2, querypid, querycamid, querytranum = self.extract_feature(query_loader)
        query_feat1 = query_feat1.cpu(); query_feat2 = query_feat2.cpu()

        gallery_feat1, gallery_feat2, gallerypid, gallerycamid, gallerytranum = self.extract_feature(gallery_loader)
        gallery_feat1 = gallery_feat1.cpu(); gallery_feat2 = gallery_feat2.cpu()

        # print(query_resfeatures.shape, gallery_resfeatures.shape)
        # querylen = len(querypid)
        # gallerylen = len(gallerypid)

        self.cnn_model = None

        # online gallery extraction
        # single_distmat = np.zeros((querylen, gallerylen))

        q_start = 0
        pooled_query = []
        for qind, qnum in enumerate(querytranum):
            query_feat1_tmp = query_feat1[q_start:q_start + qnum, :, :]
            query_feat2_tmp = query_feat2[q_start:q_start + qnum, :, :]
            pooled_query_tmp = self.att_model.selfpooling_model(query_feat1_tmp.cuda(), query_feat2_tmp.cuda(), mode='q')[0].cpu()
            pooled_query.append(pooled_query_tmp)
            q_start += qnum
            if qind % 50 == 0:
                print('self pooling model query batch {}'.format(qind))
        pooled_query = torch.cat(pooled_query, 0)

        g_start = 0
        pooled_gallery = []
        for gind, gnum in enumerate(gallerytranum):
            gallery_feat1_tmp = gallery_feat1[g_start:g_start + gnum, :, :]
            gallery_feat2_tmp = gallery_feat2[g_start:g_start + gnum, :, :]
            pooled_gallery_tmp = self.att_model.selfpooling_model(gallery_feat1_tmp.cuda(), gallery_feat2_tmp.cuda(), mode='g')[0].cpu() # bs len 768 -> bs 128
            pooled_gallery.append(pooled_gallery_tmp)
            g_start += gnum
            if gind % 50 == 0:
                print('self pooling model gallery batch {}'.format(gind))
        pooled_gallery = torch.cat(pooled_gallery, 0)

        self.selfpooling_model = None
        # pooled_query, hidden_query = self.att_model.selfpooling_model_1(query_resfeatures, query_resraw)
        # pooled_gallery, hidden_gallery = self.att_model.selfpooling_model_2(gallery_resfeatures, gallery_resraw)

        g_start = 0
        pooled_gallery_2 = []
        for gind, gnum in enumerate(gallerytranum):
            gallery_feat1_tmp = gallery_feat1[g_start:g_start + gnum, :, :]
            gallery_feat2_tmp = gallery_feat2[g_start:g_start + gnum, :, :]
            pooled_gallery_2_tmp = self.att_model.crosspooling_model(gallery_feat1_tmp.cuda(), gallery_feat2_tmp.cuda(), pooled_query.cuda()).cpu() # bs len 768, 1980+ 3 768 -> bs 1980 128
            pooled_gallery_2.append(pooled_gallery_2_tmp)
            g_start += gnum
            if gind % 50 == 0:
             print('cross pooling model gallery batch {}'.format(gind))
        pooled_gallery_2 = torch.cat(pooled_gallery_2, 1)
        del gallery_feat1, gallery_feat2, pooled_gallery_2_tmp, gallery_feat1_tmp, gallery_feat2_tmp

        q_start = 0
        pooled_query_2 = []
        for qind, qnum in enumerate(querytranum):
            torch.cuda.empty_cache()
            query_feat1_tmp = query_feat1[q_start:q_start + qnum, :, :]
            query_feat2_tmp = query_feat2[q_start:q_start + qnum, :, :]
            pooled_query_2_tmp = self.att_model.crosspooling_model(query_feat1_tmp.cuda(), query_feat2_tmp.cuda(), pooled_gallery.cuda()).cpu()
            pooled_query_2.append(pooled_query_2_tmp)
            q_start += qnum
            if qind % 50 == 0:
                print('cross pooling model query batch {}'.format(qind))
        # 第一维：gallery 第二维：query
        pooled_query_2 = torch.cat(pooled_query_2, 1)
        del query_feat1, query_feat2, pooled_query_2_tmp, query_feat1_tmp, query_feat2_tmp
        self.crosspooling_model = None


        # print('pooled_query', pooled_query.shape)
        # print('pooled_gallery_2', pooled_gallery_2.shape)
        # print('pooled_query_2', pooled_query_2.shape)
        # print('pooled_gallery', pooled_gallery.shape)
        pooled_query_2 = pooled_query_2.permute(1, 0, 2)
        pooled_query, pooled_gallery = pooled_query.unsqueeze(1), pooled_gallery.unsqueeze(0)


        encode_scores = self.verifier_model(pooled_query, pooled_gallery_2, pooled_query_2, pooled_gallery)
        # encodemat = F.softmax(encode_scores, dim=2)
        del pooled_query, pooled_gallery_2, pooled_query_2, pooled_gallery

        single_distmat_all = encode_scores[:, :, 1]
        single_distmat_all = single_distmat_all.data.cpu().numpy()
        # print('single_distmat_all', single_distmat_all.shape, single_distmat_all)

        return evaluate_seq(single_distmat_all, querypid, querycamid, gallerypid, gallerycamid)




    @torch.no_grad()
    def extract_id_info_full_seq(self, data_loader, feat_path='/data/PycharmProjects/deep-person-reid/log/vrt2/vit50_exp3/exp11_feat1feat2twotokens/eval'):
        print_freq = 10
        self.cnn_model.eval()
        self.att_model.eval()

        batch_time = AverageMeter()
        data_time = AverageMeter()
        end = time.time()

        PIDS = []
        CAMIDS = []
        TRANUM = []

        for i, data in enumerate(data_loader):
            data_time.update(time.time() - end)
            pids = data['pid']
            camids = data['camid']

            PIDS.append(pids)
            CAMIDS.append(camids)
            # TRANUM.append(imgs.shape[0])

            batch_time.update(time.time() - end)
            end = time.time()

            if (i + 1) % print_freq == 0:
                print('Extract Features: [{}/{}]\t'
                      'Time {:.3f} ({:.3f})\t'
                      'Data {:.3f} ({:.3f})\t'
                      .format(i + 1, len(data_loader),
                              batch_time.val, batch_time.avg,
                              data_time.val, data_time.avg))

        allpids = torch.cat(PIDS, 0)
        allcamids = torch.cat(CAMIDS, 0)
        torch.save(allpids, feat_path+'/gallerypid.pt')
        torch.save(allcamids, feat_path + '/gallerycamid.pt')


        return allpids, allcamids, TRANUM

    @torch.no_grad()
    def extract_feature_full_seq(self, data_loader, mode='q', feat_path='/data/PycharmProjects/deep-person-reid/log/vrt2/vit50_exp3/exp11_feat1feat2twotokens/eval'):

        assert data_loader.batch_size == 1
        print_freq = 10
        self.cnn_model.eval()
        self.att_model.eval()

        batch_time = AverageMeter()
        data_time = AverageMeter()
        end = time.time()

        # allfeatures = 0
        # allfeatures_raw = 0

        PIDS = []
        CAMIDS = []
        TRANUM = []
        allfeat1 = []
        allfeat2 = []
        i_last = 0

        for i, data in enumerate(data_loader):
            data_time.update(time.time() - end)
            # imgs = Variable(imgs, volatile=True)
            imgs = data['img'].cuda()
            # pids = data['pid']
            # camids = data['camid']

            # PIDS.append(pids)
            # CAMIDS.append(camids)
            # TRANUM.append(imgs.shape[0])

            feat1, feat2 = self.cnn_model(imgs, True) #, flows, self.mode)
            allfeat1.append(feat1.data.cpu())
            allfeat2.append(feat2.data.cpu())

            if (i+1) % 2000 == 0 or i+1 >= len(data_loader):
                print(i)
                torch.save(allfeat1, feat_path + '/{}_feat1_{}-{}.pt'.format(mode, i_last, i))
                torch.save(allfeat2, feat_path + '/{}_feat2_{}-{}.pt'.format(mode, i_last, i))

                i_last = i
                del allfeat1, allfeat2
                allfeat1 = []
                allfeat2 = []

            batch_time.update(time.time() - end)
            end = time.time()

            if (i + 1) % print_freq == 0:
                print('Extract Features: [{}/{}]\t'
                      'Time {:.3f} ({:.3f})\t'
                      'Data {:.3f} ({:.3f})\t'
                      .format(i + 1, len(data_loader),
                              batch_time.val, batch_time.avg,
                              data_time.val, data_time.avg))


        allfeat1 = torch.cat(allfeat1, 0)
        allfeat2 = torch.cat(allfeat2, 0)
        return allfeat1, allfeat2


    def evaluate_full_seq(self, query_loader, gallery_loader, feat_path='/data/PycharmProjects/deep-person-reid/log/vrt2/vit50_exp3/exp11_feat1feat2twotokens/eval'):
        # self.extract_id_info_full_seq(gallery_loader, 'q',  feat_path)
        # self.extract_feature_full_seq(query_loader, 'q', feat_path)
        # self.extract_feature_full_seq(gallery_loader, 'g', feat_path)
        # print('extraction done')



        # _, _, querypid, querycamid, querytranum = self.extract_feature(query_loader)
        # torch.save(querypid, feat_path+'/querypid.pt')
        # torch.save(querycamid, feat_path + '/querycamid.pt')
        # torch.save(querytranum, feat_path + '/querytranum.pt')

        querypid = torch.load(feat_path+'/querypid.pt')
        querycamid = torch.load(feat_path + '/querycamid.pt')
        # querytranum = torch.load(feat_path + '/querytranum.pt')

        # _, _, gallerypid, gallerycamid, gallerytranum = self.extract_feature(gallery_loader)
        # torch.save(gallerypid, feat_path + '/gallerypid.pt')
        # torch.save(gallerycamid, feat_path + '/gallerycamid.pt')
        # torch.save(gallerytranum, feat_path + '/gallerytranum.pt')

        gallerypid = torch.load(feat_path+'/gallerypid.pt')
        gallerycamid = torch.load(feat_path + '/gallerycamid.pt')

        query_feat1 = torch.load(feat_path + '/q_feat1_0-1979.pt')
        query_feat2 = torch.load(feat_path + '/q_feat2_0-1979.pt')


        gallery_feat1 = torch.load(feat_path + '/g_feat1_0-1999.pt')
        gallery_feat1.extend(torch.load(feat_path + '/g_feat1_1999-3999.pt'))
        gallery_feat1.extend(torch.load(feat_path + '/g_feat1_3999-5999.pt'))
        gallery_feat1.extend(torch.load(feat_path + '/g_feat1_5999-7999.pt'))
        gallery_feat1.extend(torch.load(feat_path + '/g_feat1_7999-9329.pt'))

        gallery_feat2 = torch.load(feat_path + '/g_feat2_0-1999.pt')
        gallery_feat2.extend(torch.load(feat_path + '/g_feat2_1999-3999.pt'))
        gallery_feat2.extend(torch.load(feat_path + '/g_feat2_3999-5999.pt'))
        gallery_feat2.extend(torch.load(feat_path + '/g_feat2_5999-7999.pt'))
        gallery_feat2.extend(torch.load(feat_path + '/g_feat2_7999-9329.pt'))

        pooled_query = []
        for i in range(len(query_feat1)):
            query_feat1_tmp = query_feat1[i]
            query_feat2_tmp = query_feat2[i]
            pooled_query_tmp = self.att_model.selfpooling_model(query_feat1_tmp.cuda(), query_feat2_tmp.cuda(), mode='q')[0].cpu()
            pooled_query.append(pooled_query_tmp)
            if i % 200 == 0:
                print('query self pooling: ', i)
        pooled_query = torch.cat(pooled_query, 0)
        # pooled_query = torch.load(feat_path+'/pooled_query.pt')


        pooled_gallery = []
        for i in range(len(gallery_feat1)):
            gallery_feat1_tmp = gallery_feat1[i]
            gallery_feat2_tmp = gallery_feat2[i]
            pooled_gallery_tmp = self.att_model.selfpooling_model(gallery_feat1_tmp.cuda(), gallery_feat2_tmp.cuda(), mode='g')[0].cpu()
            pooled_gallery.append(pooled_gallery_tmp)
            if i % 200 == 0:
                print('gallery self pooling: ', i)
        pooled_gallery = torch.cat(pooled_gallery, 0)
        # pooled_gallery = torch.load(feat_path+'/pooled_gallery.pt')
        #
        # print('q g lengths:', len(pooled_query), len(pooled_gallery))
        # print('q g:', pooled_query[:3], pooled_gallery[:3])


        pooled_gallery_2 = []
        for i in range(len(gallery_feat1)):
            gallery_feat1_tmp = gallery_feat1[i]
            gallery_feat2_tmp = gallery_feat2[i]
            torch.cuda.empty_cache()
            if gallery_feat1_tmp.shape[1] < 500:
                pooled_gallery_2_tmp = self.att_model.crosspooling_model(gallery_feat1_tmp.cuda(), gallery_feat2_tmp.cuda(), pooled_query.cuda()).cpu() # bs len 768, 1980+ 3 768 -> bs 1980 128
            else:
                # print(gallery_feat1_tmp[:,-5:,:], gallery_feat2_tmp[:,-5:,:])
                pooled_gallery_2_tmp = self.att_model.crosspooling_model(gallery_feat1_tmp[:, :12, :].cuda(), gallery_feat2_tmp[:, :12, :].cuda(), pooled_query.cuda()).cpu()
            pooled_gallery_2.append(pooled_gallery_2_tmp)
            del gallery_feat1_tmp, gallery_feat2_tmp, pooled_gallery_2_tmp
            if i % 200 == 0:
                print('gallery cross pooling:', i)

        pooled_gallery_2 = torch.cat(pooled_gallery_2, 1)
        torch.save(pooled_gallery_2, feat_path + '/pooled_gallery_2.pt')
        # pooled_gallery_2 = torch.load(feat_path + '/pooled_gallery_2.pt')
        del gallery_feat1, gallery_feat2


        pooled_query_2 = []
        for i in range(len(query_feat1)):
            query_feat1_tmp = query_feat1[i]
            query_feat2_tmp = query_feat2[i]
            torch.cuda.empty_cache()
            if query_feat1_tmp.shape[1] < 200:
                pooled_query_2_tmp = self.att_model.crosspooling_model(query_feat1_tmp.cuda(), query_feat2_tmp.cuda(), pooled_gallery.cuda()).cpu()
            else:
                # 以后改成尽可能大
                pooled_query_2_tmp = self.att_model.crosspooling_model(query_feat1_tmp[:, ::12, :].cuda(), query_feat2_tmp[:, ::12, :].cuda(), pooled_gallery.cuda()).cpu()
            pooled_query_2.append(pooled_query_2_tmp)
            del query_feat1_tmp, query_feat2_tmp, pooled_query_2_tmp
            if i % 200 == 0:
                print('query cross pooling:', i)

        pooled_query_2 = torch.cat(pooled_query_2, 1)
        torch.save(pooled_query_2, feat_path + '/pooled_query_2.pt')
        # pooled_query_2 = torch.load(feat_path + '/pooled_query_2.pt')
        del query_feat1, query_feat2
        self.crosspooling_model = None

        print('pooled_query', pooled_query.shape)
        print('pooled_gallery_2', pooled_gallery_2.shape)
        print('pooled_query_2', pooled_query_2.shape)
        print('pooled_gallery', pooled_gallery.shape)

        pooled_query_2 = pooled_query_2.permute(1, 0, 2)
        pooled_query, pooled_gallery = pooled_query.unsqueeze(1), pooled_gallery.unsqueeze(0)
        #
        #

        # torch.save(pooled_query, feat_path+'/pooled_query.pt')
        # torch.save(pooled_gallery_2, feat_path + '/pooled_gallery_2.pt')
        # torch.save(pooled_query_2, feat_path + '/pooled_query_2.pt')
        # torch.save(pooled_gallery, feat_path + '/pooled_gallery.pt')
        print('pooled features saved')

        encode_scores = self.verifier_model(pooled_query, pooled_gallery_2, pooled_query_2, pooled_gallery)
        # encodemat = F.softmax(encode_scores, dim=2)
        del pooled_query, pooled_gallery_2, pooled_query_2, pooled_gallery
        #
        single_distmat_all = encode_scores[:, :, 1]
        single_distmat_all = single_distmat_all.data.cpu().numpy()
        # # print('single_distmat_all', single_distmat_all.shape, single_distmat_all)


        return evaluate_seq(single_distmat_all, querypid, querycamid, gallerypid, gallerycamid)
