import torchreid
import torch

# HyperParams
BATCH_SIZE = 48
NUM_INSTANCES = 4
BATCH_SIZE_TEST = 256
TRANSFORMS = ['random_flip', 'random_crop', 'norm_mean', 'norm_std', 'color_jitter', 'random_patch']  # 'random_erase'
SEQ_LEN = 4
MODEL_NAME = 'scan_transformer_small_resnet26d'
PRETRAIN = True
LOSS_TYPE = ['oim', 'softmax']
OPTIM = 'sgd'
INIT_LR = 0.0
LR_SCHEDULAR = 'cyclic'
LR_SCHEDULAR_STEPSIZE = 157 * 2
MAX_LR = 0.001   #25  # 25
BASE_LR = 0.0001
WEIGHT_OIMLOSS = 0.005
WEIGHT_CELOSS = 1.0
WEIGHT_VERLOSS = 5000.0
LABEL_SMOOTH = True
LOG_DIR = '/data/PycharmProjects/deep-person-reid/log/scan/scan_transformer_small_resnet26d_exp4'
MAX_EPOCH = 400
EVAL_FREQ = 4  # which is save_freq here

# Load data manager
datamanager = torchreid.data.VideoDataManager(
    root='/data/reid-data',
    sources='mars',
    targets='mars',
    height=224,  # 256, 128
    width=224,
    batch_size_train=BATCH_SIZE,
    batch_size_test=BATCH_SIZE_TEST,
    transforms=TRANSFORMS,
    norm_mean=[0.4058, 0.3852, 0.3730],
    norm_std=[0.2049, 0.1984, 0.1956],
    seq_len=SEQ_LEN,
    train_sampler='RandomIdentitySampler',
    num_instances=NUM_INSTANCES,
)


# Build model, optimizer and lr_scheduler
model = torchreid.models.build_model(
    name=MODEL_NAME,
    num_classes=datamanager.num_train_pids,
    loss=LOSS_TYPE,
    pretrained=PRETRAIN
)

model = model.cuda()

optimizer = torchreid.optim.build_optimizer(
    model,
    optim=OPTIM,
    lr=INIT_LR,
    staged_lr=True,
    new_layers=['backbone.blocks'], base_lr_mult=0.1  # 'transformer.pos_embedding.pos_embedding',
)

scheduler = torchreid.optim.build_lr_scheduler(
    optimizer,
    lr_scheduler=LR_SCHEDULAR,
    step_size_up=LR_SCHEDULAR_STEPSIZE,
    step_size_down=LR_SCHEDULAR_STEPSIZE,
    max_lr=MAX_LR,
    base_lr=BASE_LR
)

# Build engine
engine = torchreid.engine.VideoOIMPairLossEngine(
    datamanager,
    model,
    optimizer=optimizer,
    scheduler=scheduler,
    weight_o=WEIGHT_OIMLOSS,
    weight_v=WEIGHT_VERLOSS,
    weight_c=WEIGHT_CELOSS,
    label_smooth=LABEL_SMOOTH
)

# Load a trained backbone
torchreid.utils.resume_from_checkpoint('/data/PycharmProjects/deep-person-reid/log/scan/scan_transformer_small_resnet26d_exp3/model/model.pth.tar-400',
                                       model, optimizer, scheduler)

# torchreid.utils.load_pretrained_weights(model.backbone, '/data/PycharmProjects/deep-person-reid/log/deit/oim/saved_checkpoints/model.pth.tar-135')
# torchreid.utils.load_pretrained_weights(model,
#                                         '/data/PycharmProjects/deep-person-reid/log/scan/scan_transformer_small_resnet26d_exp3/model/model.pth.tar-12')
#
# Run training and test
engine.run(
    save_dir=LOG_DIR,
    # start_epoch=60,
    max_epoch=MAX_EPOCH,
    eval_freq=EVAL_FREQ,
    print_freq=20,
    amp=True,
    test_only=False
)
