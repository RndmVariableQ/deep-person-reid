import torchreid
import torch



# HyperParams
BATCH_SIZE = 64
NUM_INSTANCES = 4
BATCH_SIZE_TEST = 128
TRANSFORMS = ['random_flip', 'random_crop', 'norm_mean', 'norm_std', 'color_jitter', 'random_patch']  # 'random_erase'
SEQ_LEN = 2
MODEL_NAME = 'Vrt2_vit26d'
PRETRAIN = True
LOSS_TYPE = 'oim'
OPTIM = 'sgd'
INIT_LR = 0.0
LR_SCHEDULAR = 'cyclic'
LR_SCHEDULAR_STEPSIZE = 157 * 2
MAX_LR = 0.002   #25  # 25
BASE_LR = 0.002
WEIGHT_OIMLOSS = 0.005
WEIGHT_CELOSS = 1.0
WEIGHT_VERLOSS = 50000.0 # 太高模型就会为了去verify而破坏了representation learning
LABEL_SMOOTH = True
LOG_DIR = '/data/PycharmProjects/deep-person-reid/log/vrt2/exp0/1'
MAX_EPOCH = 400
EVAL_FREQ = 8

# Load data manager
datamanager = torchreid.data.VideoDataManager(
    root='/data/reid-data',
    sources='mars',
    targets='mars',
    height=224,  # 256, 128
    width=224,
    batch_size_train=BATCH_SIZE,
    batch_size_test=BATCH_SIZE_TEST,
    transforms=TRANSFORMS,
    norm_mean=[0.4058, 0.3852, 0.3730],
    norm_std=[0.2049, 0.1984, 0.1956],
    seq_len=SEQ_LEN,
    train_sampler='RandomIdentitySampler',
    num_instances=NUM_INSTANCES,
)


# Build model, optimizer and lr_scheduler
model = torchreid.models.build_model(
    name=MODEL_NAME,
    num_classes=datamanager.num_train_pids,
    loss=LOSS_TYPE,
    pretrained=PRETRAIN
)

model = model.cuda()

optimizer = torchreid.optim.build_optimizer(
    model,
    optim=OPTIM,
    lr=INIT_LR,
    staged_lr=True,
    # new_layers=['att_model'], base_lr_mult=0.1,
    # fixed_layers=['backbone']
)

scheduler = torchreid.optim.build_lr_scheduler(
    optimizer,
    lr_scheduler=LR_SCHEDULAR,
    step_size_up=LR_SCHEDULAR_STEPSIZE,
    step_size_down=LR_SCHEDULAR_STEPSIZE,
    max_lr=MAX_LR,
    base_lr=BASE_LR
)

# Build engine
engine = torchreid.engine.VideoSCANEngine(
    datamanager,
    model,
    optimizer=optimizer,
    scheduler=scheduler,
    weight_o=WEIGHT_OIMLOSS,
    weight_v=WEIGHT_VERLOSS,
    weight_c=WEIGHT_CELOSS,
    label_smooth=LABEL_SMOOTH
)
print(model)
# Load a trained backbone
#[1]
# torchreid.utils.resume_from_checkpoint('/data/PycharmProjects/deep-person-reid/log/scan/scan_transformer_small_resnet26d_exp3/model/model.pth.tar-400',
#                                        model, optimizer, scheduler)
#[2]
torchreid.utils.load_pretrained_weights(model, '/data/PycharmProjects/deep-person-reid/log/vreid_tr/0127_vit26d_exp0/model/model.pth.tar-32')

#[3]
# torchreid.utils.load_pretrained_weights(model,
#                                         '/data/PycharmProjects/deep-person-reid/log/scan/scan_transformer_small_resnet26d_exp3/model/model.pth.tar-12')

torch.cuda.empty_cache()
torch.backends.cudnn.benchmark = True

# Run training and test
engine.run(
    save_dir=LOG_DIR,
    # start_epoch=61,
    max_epoch=MAX_EPOCH,
    eval_freq=EVAL_FREQ,
    print_freq=25,
    amp=True,
    test_only=False
)
