import torchreid
import torch

# HyperParams
BATCH_SIZE = 32
NUM_INSTANCES = 4
BATCH_SIZE_TEST = 200
TRANSFORMS = ['random_flip', 'random_crop', 'norm_mean', 'norm_std', 'color_jitter', 'random_patch']  # 'random_erase'
SEQ_LEN = 3
MODEL_NAME = 'scan_transformer_small_resnet50d'
PRETRAIN = True
LOSS_TYPE = ''
OPTIM = 'sgd'
INIT_LR = 1e-3
LR_SCHEDULAR = 'cyclic'
LR_SCHEDULAR_STEPSIZE = 241 * 4
MAX_LR = 0.005 #25  # 25
BASE_LR = 0.0001
WEIGHT_OIMLOSS = 0.01
WEIGHT_VERLOSS = 5000.0
LABEL_SMOOTH = True
LOG_DIR = '/data/PycharmProjects/deep-person-reid/log/scan/scan_transformer_small_resnet26d_exp1'
MAX_EPOCH = 400
EVAL_FREQ = 8  # which is save_freq here


# Load data manager
# datamanager = torchreid.data.VideoDataManager(
#     root='/data/reid-data',
#     sources='mars',
#     targets='mars',
#     height=224,  # 256, 128
#     width=224,
#     batch_size_train=BATCH_SIZE,
#     batch_size_test=BATCH_SIZE_TEST,
#     transforms=TRANSFORMS,
#     norm_mean=[0.4058, 0.3852, 0.3730],
#     norm_std=[0.2049, 0.1984, 0.1956],
#     seq_len=SEQ_LEN,
#     train_sampler='RandomIdentitySampler',
#     num_instances=NUM_INSTANCES,
# )

# Build model, optimizer and lr_scheduler
model = torchreid.models.build_model(
    name=MODEL_NAME,
    num_classes=650,
    loss=LOSS_TYPE,
    pretrained=PRETRAIN
)

# model = model.cuda()

torchreid.utils.load_pretrained_weights(model,
                                        '/data/PycharmProjects/deep-person-reid/log/scan/saved/scan_small_50d_model.pth.tar-14')


print(list(model.backbone.blocks[0].attn.qkv.parameters()))
# for v in list(model.backbone.parameters()):
#     print(k)

