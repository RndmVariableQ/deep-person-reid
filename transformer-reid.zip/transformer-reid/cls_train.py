import torchreid
import torch


# HyperParams
BATCH_SIZE = 18
TRANSFORMS = ['random_flip', 'random_crop', 'norm_mean', 'norm_std', 'color_jitter', 'random_patch', 'random_erase']  # 'random_erase', 'color_jitter', 'random_patch'
SAMPLE_METHOD = 'evenly'
SEQ_LEN = 2
MODEL_NAME = 'Vrt2_vit50d'
PRETRAIN = True
OPTIM = 'sgd'
INIT_LR = 1e-4
LR_SCHEDULAR = 'cyclic'
LR_SCHEDULAR_STEPSIZE = 209*4
MAX_LR = 0.005 #25
BASE_LR = 0.00001
WEIGHT_OIMLOSS = 0.001
WEIGHT_VERLOSS = 10000.

LABEL_SMOOTH = True
LOG_DIR = 'log/vrt2/vit50_exp3/exp12_seqlen8_feat1feat2twotokens____test'
MAX_EPOCH = 400
EVAL_FREQ = 4

BATCH_SIZE_TEST = 64
TEST_SEQ_LEN = 3
# Vrt2_resnet50

# TSA_resnet50
# feat1平均， 再算cosine对每一帧额feat2加权   map: 0.6949 top1acc 0.79+
# feat1做完attn norm直接位乘feat2           map: 0.7211 top1acc 0.8043     seqlen=20的测试：0.812%

# Load data manager
datamanager = torchreid.data.VideoDataManager(
    root='/data/reid-data',
    sources='mars',
    targets='mars',
    height=224,  # 256, 128
    width=224,
    batch_size_train=BATCH_SIZE,
    batch_size_test=BATCH_SIZE_TEST,
    transforms=TRANSFORMS,
    norm_mean=[0.4058, 0.3852, 0.3730],
    norm_std=[0.2049, 0.1984, 0.1956],
    train_sampler='RandomIdentitySampler',
    seq_len=SEQ_LEN,
    test_seq_len=TEST_SEQ_LEN,
    sample_method=SAMPLE_METHOD

)


# Build model, optimizer and lr_scheduler
model = torchreid.models.build_model(
    name=MODEL_NAME,
    num_classes=datamanager.num_train_pids,
    pretrained=PRETRAIN
)

torch.cuda.empty_cache()
model = model.cuda()


optimizer = torchreid.optim.build_optimizer(
    model,
    optim=OPTIM,
    lr=INIT_LR,
    staged_lr=True,
    new_layers=['att_model'], base_lr_mult=0.1,   # 'transformer.pos_embedding.pos_embedding',
    # fixed_layers=['backbone']
)

scheduler = torchreid.optim.build_lr_scheduler(
    optimizer,
    lr_scheduler=LR_SCHEDULAR,
    step_size_up=LR_SCHEDULAR_STEPSIZE,
    step_size_down=LR_SCHEDULAR_STEPSIZE,
    max_lr=MAX_LR,
    base_lr=BASE_LR
)

# scheduler = torchreid.optim.build_lr_scheduler(
#     optimizer)

# print(model)

# Build engine
engine = torchreid.engine.VideoOIMPairLossEngine(
    datamanager,
    model,
    optimizer=optimizer,
    scheduler=scheduler,
    weight_o=WEIGHT_OIMLOSS,
    weight_v=WEIGHT_VERLOSS,
    label_smooth=LABEL_SMOOTH
)

# Load a trained model
# torchreid.utils.load_pretrained_weights(model.backbone, '/data/PycharmProjects/deep-person-reid/log/saved/vit50d_top1_8076_map7351.pth.tar-120')

torchreid.utils.resume_from_checkpoint('/data/PycharmProjects/deep-person-reid/log/vrt2/vit50_exp3/exp11_feat1feat2twotokens/model/model.pth.tar-308', model)


# print(model)


# Run training and test
engine.run(
    save_dir=LOG_DIR,
    start_epoch=191,
    max_epoch=MAX_EPOCH,
    eval_freq=EVAL_FREQ,
    print_freq=20,
    amp=True,
    test_only=False
)


