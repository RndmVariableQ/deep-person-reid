import torchreid


#     torchreid.models.show_avai_models()

# Load data manager
datamanager = torchreid.data.VideoDataManager(
    root='/data/reid-data',
    sources='mars',
    targets='mars',
    height=224, #256, 128
    width=224,
    batch_size_train=32,
    batch_size_test=100,
    transforms=['random_flip', 'random_crop', 'norm_mean', 'norm_std'],
    norm_mean= [0.4058, 0.3852, 0.3730],
    norm_std= [0.2049, 0.1984, 0.1956],
    seq_len=5
)


# Build model, optimizer and lr_scheduler
model = torchreid.models.build_model(
    name='osnet_x1_0',
    num_classes=datamanager.num_train_pids,
    loss='triplet',
    pretrained=False
)

model = model.cuda()


optimizer = torchreid.optim.build_optimizer(
    model,
    optim='sgd',
    lr=0.02,
    new_layers=['classifier.bias', 'classifier.weight'], base_lr_mult=0.1 # 'transformer.pos_embedding.pos_embedding',
)

scheduler = torchreid.optim.build_lr_scheduler(
    optimizer,
    lr_scheduler='single_step',
    stepsize=20
)


# Build engine
engine = torchreid.engine.VideoTripletEngine(
    datamanager,
    model,
    optimizer=optimizer,
    scheduler=scheduler,
    label_smooth=True
)

# Load a trained model
torchreid.utils.load_pretrained_weights(model, '/home/cytus/PycharmProject/deep-person-reid/log/osnet_x1_0/osnet_x1_0_imagenet.pth')


# Continue training
# start_epoch = torchreid.utils.resume_from_checkpoint(
#     'log/vit12/model/model.pth.tar-15',
#     model,
#     optimizer
# )


# Run training and test
engine.run(
    save_dir='log/osnet_x1_0/pretrain_triplet_sgd',
    # start_epoch=start_epoch,
    max_epoch=100,
    eval_freq=5,
    print_freq=20,
    test_only=False
)

