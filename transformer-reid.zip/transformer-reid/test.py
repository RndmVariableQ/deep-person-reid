import torchreid
import torch
import os

# os.environ['CUDA_LAUNCH_BLOCKING'] = 1
# torch.backends.cudnn.benchmark = True

# HyperParams
BATCH_SIZE = 1
NUM_INSTANCES = 1
TRANSFORMS = ['random_flip', 'random_crop', 'norm_mean', 'norm_std', 'color_jitter', 'random_patch']  # 'random_erase', 'color_jitter', 'random_patch'


MODEL_NAME = 'Vrt2_vit50d'
BATCH_SIZE_TEST = 64
TEST_SEQ_LEN = 3
TEST_SAMPLE_METHOD = 'evenly'


# Load data manager
datamanager = torchreid.data.VideoDataManager(
    root='/data/reid-data',
    sources='mars',
    targets='mars',
    height=224,  # 256, 128
    width=224,
    batch_size_train=BATCH_SIZE,
    batch_size_test=BATCH_SIZE_TEST,
    transforms=TRANSFORMS,
    norm_mean=[0.4058, 0.3852, 0.3730],
    norm_std=[0.2049, 0.1984, 0.1956],
    train_sampler='RandomIdentitySampler',
    num_instances=NUM_INSTANCES,
    test_seq_len=TEST_SEQ_LEN,
    test_sample_method=TEST_SAMPLE_METHOD
)


# Build model, optimizer and lr_scheduler
model = torchreid.models.build_model(
    name=MODEL_NAME,
    num_classes=625
)

model = model.cuda()
torchreid.utils.load_pretrained_weights(model, '/data/PycharmProjects/deep-person-reid/log/vrt2/vit50_exp3/exp11_feat1feat2twotokens/model/model.pth.tar-291')


# Build engine
engine = torchreid.engine.VideoOIMPairLossEngine(
    datamanager,
    model,
    optimizer=None,
    scheduler=None,
)

# Run training and test
mAP, rank1, rank5 = \
    engine.run(
    save_dir='',
    # start_epoch=33,
    max_epoch=1,
    eval_freq=None,
    print_freq=20,
    test_only=True
)


